"use client"

import { useState, useTransition } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { User, Shield, Loader2 } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"
import { useToast } from "@/hooks/use-toast"
import { AuthGuard } from "@/components/auth-guard"
import { Navbar } from "@/components/navbar"
import { validateUserCredentialsAction, updateUserAction } from "@/lib/user-actions"
import { useRouter } from "next/navigation"

interface PasswordFormData {
  currentPassword: string
  newPassword: string
  confirmPassword: string
}

export default function ProfileSettings() {
  const { user, logout } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const [isPending, startTransition] = useTransition()

  const [passwordData, setPasswordData] = useState<PasswordFormData>({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  const validatePasswordForm = (): boolean => {
    if (!passwordData.currentPassword) {
      toast({
        title: "Validation Error",
        description: "Current password is required",
        variant: "destructive",
      })
      return false
    }

    if (!passwordData.newPassword) {
      toast({
        title: "Validation Error",
        description: "New password is required",
        variant: "destructive",
      })
      return false
    }

    if (passwordData.newPassword.length < 6) {
      toast({
        title: "Validation Error",
        description: "New password must be at least 6 characters long",
        variant: "destructive",
      })
      return false
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast({
        title: "Validation Error",
        description: "New passwords do not match",
        variant: "destructive",
      })
      return false
    }

    return true
  }

  const handleChangePassword = async () => {
    if (!user?.username || !user?.id || !validatePasswordForm()) return

    try {
      startTransition(async () => {
        // First validate current password
        const validationResult = await validateUserCredentialsAction(user.username, passwordData.currentPassword)

        if (!validationResult.success) {
          toast({
            title: "Error",
            description: "Current password is incorrect",
            variant: "destructive",
          })
          return
        }

        // Update password
        const formData = new FormData()
        formData.append("name", user.name)
        formData.append("email", user.email || "")
        formData.append("password", passwordData.newPassword)
        formData.append("department", user.department || "")
        formData.append("role", user.role.toUpperCase()) // Convert to Prisma format

        const result = await updateUserAction(user.id, formData)

        if (result.success) {
          toast({
            title: "Success",
            description: "Password updated successfully. Please login again.",
          })

          // Clear form
          setPasswordData({
            currentPassword: "",
            newPassword: "",
            confirmPassword: "",
          })

          // Logout and redirect to login after a short delay
          setTimeout(() => {
            logout()
            router.push("/login")
          }, 2000)
        } else {
          toast({
            title: "Error",
            description: result.error || "Failed to update password",
            variant: "destructive",
          })
        }
      })
    } catch (error) {
      console.error("Error updating password:", error)
      toast({
        title: "Error",
        description: "Failed to update password",
        variant: "destructive",
      })
    }
  }

  if (!user) {
    return (
      <div className="container mx-auto p-6 flex items-center justify-center min-h-96">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-gray-500">Loading profile...</p>
        </div>
      </div>
    )
  }

  return (
    <AuthGuard
      allowedRoles={["admin", "doctor", "nurse", "technician", "pharmacist", "patient"]}
      className="container mx-auto p-6 space-y-6"
    >
      <Navbar />
      <div className="max-w-4xl mx-auto px-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Profile Settings</h1>
            <p className="text-gray-500">View your account information and change your password</p>
          </div>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 bg-white">
            <TabsTrigger value="profile">Profile Information</TabsTrigger>
            <TabsTrigger value="security">Change Password</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <User className="h-5 w-5 text-blue-600" />
                  <span>Personal Information</span>
                </CardTitle>
                <CardDescription>Your account details (read-only)</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">Username</Label>
                    <div className="p-3 bg-gray-50 rounded-md border">
                      <p className="text-sm font-mono">{user.username}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">Full Name</Label>
                    <div className="p-3 bg-gray-50 rounded-md border">
                      <p className="text-sm">{user.name}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">Email Address</Label>
                    <div className="p-3 bg-gray-50 rounded-md border">
                      <p className="text-sm">{user.email || "Not provided"}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">Department</Label>
                    <div className="p-3 bg-gray-50 rounded-md border">
                      <p className="text-sm">{user.department || "Not assigned"}</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">Role</Label>
                    <div className="p-3 bg-gray-50 rounded-md border">
                      <Badge className="bg-blue-100 text-blue-800 border-blue-200 capitalize">{user.role}</Badge>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">User ID</Label>
                    <div className="p-3 bg-gray-50 rounded-md border">
                      <p className="text-xs font-mono text-gray-600">{user.id}</p>
                    </div>
                  </div>
                </div>

                {user.permissions && user.permissions.length > 0 && (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">Permissions</Label>
                    <div className="p-3 bg-gray-50 rounded-md border">
                      <div className="flex flex-wrap gap-2">
                        {user.permissions.map((permission, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {permission}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800">
                    <strong>Note:</strong> To update your personal information, please contact your system
                    administrator.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-5 w-5 text-blue-600" />
                  <span>Change Password</span>
                </CardTitle>
                <CardDescription>Update your account password for security</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="max-w-md space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="current-password">Current Password *</Label>
                    <Input
                      id="current-password"
                      type="password"
                      placeholder="Enter your current password"
                      value={passwordData.currentPassword}
                      onChange={(e) => setPasswordData((prev) => ({ ...prev, currentPassword: e.target.value }))}
                      disabled={isPending}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="new-password">New Password *</Label>
                    <Input
                      id="new-password"
                      type="password"
                      placeholder="Enter your new password"
                      value={passwordData.newPassword}
                      onChange={(e) => setPasswordData((prev) => ({ ...prev, newPassword: e.target.value }))}
                      disabled={isPending}
                    />
                    <p className="text-xs text-gray-500">Password must be at least 6 characters long</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="confirm-password">Confirm New Password *</Label>
                    <Input
                      id="confirm-password"
                      type="password"
                      placeholder="Confirm your new password"
                      value={passwordData.confirmPassword}
                      onChange={(e) => setPasswordData((prev) => ({ ...prev, confirmPassword: e.target.value }))}
                      disabled={isPending}
                    />
                  </div>

                  <Button onClick={handleChangePassword} disabled={isPending} className="w-full">
                    {isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Updating Password...
                      </>
                    ) : (
                      "Change Password"
                    )}
                  </Button>
                </div>

                <div className="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <p className="text-sm text-yellow-800">
                    <strong>Important:</strong> After changing your password, you will be automatically logged out and
                    redirected to the login page.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AuthGuard>
  )
}
