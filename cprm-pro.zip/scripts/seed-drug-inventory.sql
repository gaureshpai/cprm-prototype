-- Seed the drug inventory with common medications
INSERT INTO drug_inventory (drug_name, current_stock, min_stock, status, category, location, batch_number, expiry_date) VALUES
-- Pain Relief & Anti-inflammatory
('Paracetamol 500mg', 500, 50, 'normal', 'Analgesic', 'Main Pharmacy', 'PCM001', '2025-12-31'),
('Ibuprofen 400mg', 300, 30, 'normal', 'NSAID', 'Main Pharmacy', 'IBU001', '2025-11-30'),
('Aspirin 75mg', 200, 25, 'normal', 'Antiplatelet', 'Main Pharmacy', 'ASP001', '2025-10-31'),
('Diclofenac 50mg', 150, 20, 'normal', 'NSAID', 'Main Pharmacy', 'DIC001', '2025-09-30'),

-- Antibiotics
('Amoxicillin 500mg', 400, 40, 'normal', 'Antibiotic', 'Main Pharmacy', 'AMX001', '2025-08-31'),
('Azithromycin 250mg', 250, 25, 'normal', 'Antibiotic', 'Main Pharmacy', 'AZI001', '2025-07-31'),
('Ciprofloxacin 500mg', 180, 20, 'normal', 'Antibiotic', 'Main Pharmacy', 'CIP001', '2025-06-30'),
('Cephalexin 500mg', 220, 25, 'normal', 'Antibiotic', 'Main Pharmacy', 'CEP001', '2025-05-31'),

-- Cardiovascular
('Amlodipine 5mg', 350, 35, 'normal', 'Antihypertensive', 'Main Pharmacy', 'AML001', '2026-01-31'),
('Atenolol 50mg', 280, 30, 'normal', 'Beta Blocker', 'Main Pharmacy', 'ATE001', '2025-12-31'),
('Lisinopril 10mg', 320, 35, 'normal', 'ACE Inhibitor', 'Main Pharmacy', 'LIS001', '2025-11-30'),
('Simvastatin 20mg', 200, 25, 'normal', 'Statin', 'Main Pharmacy', 'SIM001', '2025-10-31'),

-- Diabetes
('Metformin 500mg', 450, 50, 'normal', 'Antidiabetic', 'Main Pharmacy', 'MET001', '2026-02-28'),
('Glimepiride 2mg', 180, 20, 'normal', 'Antidiabetic', 'Main Pharmacy', 'GLI001', '2025-09-30'),
('Insulin Glargine', 100, 15, 'normal', 'Insulin', 'Refrigerated Storage', 'INS001', '2025-08-31'),

-- Respiratory
('Salbutamol Inhaler', 80, 10, 'normal', 'Bronchodilator', 'Main Pharmacy', 'SAL001', '2025-12-31'),
('Montelukast 10mg', 150, 20, 'normal', 'Leukotriene Antagonist', 'Main Pharmacy', 'MON001', '2025-11-30'),
('Prednisolone 5mg', 200, 25, 'normal', 'Corticosteroid', 'Main Pharmacy', 'PRE001', '2025-10-31'),

-- Gastrointestinal
('Omeprazole 20mg', 300, 35, 'normal', 'PPI', 'Main Pharmacy', 'OME001', '2025-12-31'),
('Ranitidine 150mg', 250, 30, 'normal', 'H2 Blocker', 'Main Pharmacy', 'RAN001', '2025-11-30'),
('Loperamide 2mg', 120, 15, 'normal', 'Antidiarrheal', 'Main Pharmacy', 'LOP001', '2025-10-31'),

-- Vitamins & Supplements
('Vitamin D3 1000IU', 400, 40, 'normal', 'Vitamin', 'Main Pharmacy', 'VIT001', '2026-03-31'),
('Folic Acid 5mg', 300, 30, 'normal', 'Vitamin', 'Main Pharmacy', 'FOL001', '2026-02-28'),
('Iron Tablets 65mg', 250, 25, 'normal', 'Mineral', 'Main Pharmacy', 'IRO001', '2025-12-31'),

-- Low Stock Items (to demonstrate low stock warnings)
('Morphine 10mg', 8, 10, 'low', 'Opioid', 'Controlled Drugs Cabinet', 'MOR001', '2025-08-31'),
('Warfarin 5mg', 12, 15, 'low', 'Anticoagulant', 'Main Pharmacy', 'WAR001', '2025-07-31'),

-- Out of Stock Items
('Tramadol 50mg', 0, 20, 'out_of_stock', 'Opioid', 'Main Pharmacy', 'TRA001', '2025-06-30'),
('Codeine 30mg', 0, 15, 'out_of_stock', 'Opioid', 'Controlled Drugs Cabinet', 'COD001', '2025-05-31');
