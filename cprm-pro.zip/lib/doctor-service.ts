"use server"

import { PrismaClient } from "@prisma/client"
import { revalidatePath } from "next/cache"

const prisma = new PrismaClient()

export interface PatientData {
  id: string
  name: string
  age: number
  gender: string
  phone?: string | null
  address?: string | null
  condition?: string | null
  status: string
  allergies: string[]
  bloodType?: string | null
  emergencyContact?: string | null
  emergencyPhone?: string | null
  vitals: {
    bp?: string
    pulse?: string
    temp?: string
    weight?: string
    height?: string
  }
  lastVisit?: Date | null
  nextAppointment?: Date | null
  medications: Array<{
    id: string
    name: string
    dosage: string
    frequency: string
    duration: string
    instructions?: string | null
    drugInfo: {
      id: string
      currentStock: number
      minStock: number
      status: string
      category?: string | null
      batchNumber?: string | null
      expiryDate?: Date | null
      location: string
    }
    prescriptionDate: Date
  }>
  medicalHistory: Array<{
    id: string
    date: Date
    diagnosis: string
    treatment?: string
    notes?: string
  }>
  createdAt: Date
  updatedAt: Date
}

export interface AppointmentData {
  id: string
  patientId: string
  doctorId: string
  date: Date
  time: string
  status: string
  type: string
  notes?: string | null
  patient: {
    name: string
    age: number
    condition?: string | null
  }
  createdAt: Date
}

export interface PrescriptionData {
  id: string
  patientId: string
  doctorId: string
  status: string
  notes?: string | null
  items: PrescriptionItemData[]
  patient: {
    name: string
    age: number
  }
  createdAt: Date
}

export interface PrescriptionItemData {
  id: string
  drugId: string
  dosage: string
  frequency: string
  duration: string
  instructions?: string | null
  drug: {
    id: string
    drugName: string
    currentStock: number
    minStock: number
    status: string
    category?: string | null
    batchNumber?: string | null
    expiryDate?: Date | null
    location: string
  }
}

export interface MedicalRecordData {
  id: string
  patientId: string
  doctorId: string
  visitDate: Date
  diagnosis: string
  symptoms: string[]
  treatment?: string | null
  notes?: string | null
  vitals: any
  followUpRequired: boolean
  followUpDate?: Date | null
  patient: {
    name: string
    age: number
  }
}

export interface CreatePrescriptionData {
  patientId: string
  doctorUsername: string // Changed from doctorId to doctorUsername
  notes?: string
  medications: {
    drugName: string
    dosage: string
    frequency: string
    duration: string
    instructions?: string
  }[]
}

export interface CreateMedicalRecordData {
  patientId: string
  doctorId: string
  diagnosis: string
  symptoms: string[]
  treatment?: string
  notes?: string
  vitals?: any
  followUpRequired: boolean
  followUpDate?: string
}

// Helper function to get or create doctor by username
async function getOrCreateDoctorByUsername(username: string): Promise<string> {
  try {
    // First try to find existing doctor
    let doctor = await prisma.user.findFirst({
      where: {
        username: username,
        role: "DOCTOR",
      },
    })

    if (!doctor) {
      // Create doctor if doesn't exist (for demo users)
      doctor = await prisma.user.create({
        data: {
          username: username,
          name: username,
          email: `${username.toLowerCase().replace(/\s+/g, ".")}@wenlock.hospital`,
          password: "demo123", // Default password for demo doctors
          role: "DOCTOR",
          status: "ACTIVE",
          permissions: ["patient_management", "appointments", "prescriptions", "medical_records"],
        },
      })
      console.log(`Created new doctor: ${username} with ID: ${doctor.id}`)
    }

    return doctor.id
  } catch (error) {
    console.error("Error getting/creating doctor:", error)
    throw new Error(`Failed to get doctor with username: ${username}`)
  }
}

// Get doctor's appointments for a specific date
export async function getDoctorAppointments(doctorUsername: string, date?: Date): Promise<AppointmentData[]> {
  try {
    const doctorId = await getOrCreateDoctorByUsername(doctorUsername)

    const targetDate = date || new Date()
    const startOfDay = new Date(targetDate)
    startOfDay.setHours(0, 0, 0, 0)
    const endOfDay = new Date(targetDate)
    endOfDay.setHours(23, 59, 59, 999)

    const appointments = await prisma.appointment.findMany({
      where: {
        doctorId,
        date: {
          gte: startOfDay,
          lte: endOfDay,
        },
      },
      include: {
        patient: {
          select: {
            name: true,
            age: true,
            condition: true,
          },
        },
      },
      orderBy: {
        time: "asc",
      },
    })

    return appointments.map((appointment) => ({
      id: appointment.id,
      patientId: appointment.patientId,
      doctorId: appointment.doctorId,
      date: appointment.date,
      time: appointment.time,
      status: appointment.status,
      type: appointment.type.toString(), // Convert enum to string
      notes: appointment.notes,
      patient: appointment.patient,
      createdAt: appointment.createdAt,
    }))
  } catch (error) {
    console.error("Error fetching doctor appointments:", error)
    throw new Error("Failed to fetch appointments")
  }
}

// Get all patients with enhanced medication data from drug inventory
export async function getDoctorPatients(doctorUsername: string, limit = 50): Promise<PatientData[]> {
  try {
    // Get all patients from the system, not just those with appointments with this doctor
    const patients = await prisma.patient.findMany({
      where: {
        status: "Active", // Only show active patients
      },
      include: {
        prescriptions: {
          include: {
            items: {
              include: {
                drug: {
                  select: {
                    id: true,
                    drugName: true,
                    currentStock: true,
                    minStock: true,
                    status: true,
                    category: true,
                    batchNumber: true,
                    expiryDate: true,
                    location: true,
                  },
                },
              },
            },
          },
          orderBy: {
            createdAt: "desc",
          },
          take: 5, // Get latest 5 prescriptions
        },
      },
      orderBy: {
        lastVisit: "desc",
      },
      take: limit,
    })

    return patients.map((patient) => ({
      id: patient.id,
      name: patient.name,
      age: patient.age,
      gender: patient.gender,
      phone: patient.phone,
      address: patient.address,
      condition: patient.condition,
      status: patient.status,
      allergies: patient.allergies || [],
      bloodType: patient.bloodType,
      emergencyContact: patient.emergencyContact,
      emergencyPhone: patient.emergencyPhone,
      vitals:
        typeof patient.vitals === "object" && patient.vitals !== null
          ? (patient.vitals as { bp?: string; pulse?: string; temp?: string; weight?: string; height?: string })
          : { bp: "", pulse: "", temp: "", weight: "", height: "" },
      lastVisit: patient.lastVisit,
      nextAppointment: patient.nextAppointment,
      medications: patient.prescriptions.flatMap((prescription) =>
        prescription.items.map((item) => ({
          id: item.id,
          name: item.drug.drugName,
          dosage: item.dosage,
          frequency: item.frequency,
          duration: item.duration,
          instructions: item.instructions,
          drugInfo: {
            id: item.drug.id,
            currentStock: item.drug.currentStock,
            minStock: item.drug.minStock,
            status: item.drug.status,
            category: item.drug.category,
            batchNumber: item.drug.batchNumber,
            expiryDate: item.drug.expiryDate,
            location: item.drug.location,
          },
          prescriptionDate: prescription.createdAt,
        })),
      ),
      medicalHistory: [], // TODO: Implement when medical records table is available
      createdAt: patient.createdAt,
      updatedAt: patient.updatedAt,
    }))
  } catch (error) {
    console.error("Error fetching all patients:", error)
    throw new Error("Failed to fetch patients")
  }
}

// Search patients with enhanced medication data
export async function searchPatients(query: string, limit = 20): Promise<PatientData[]> {
  try {
    const patients = await prisma.patient.findMany({
      where: {
        OR: [
          { name: { contains: query, mode: "insensitive" } },
          { id: { contains: query, mode: "insensitive" } },
          { phone: { contains: query } },
        ],
        status: "Active",
      },
      include: {
        prescriptions: {
          include: {
            items: {
              include: {
                drug: {
                  select: {
                    id: true,
                    drugName: true,
                    currentStock: true,
                    minStock: true,
                    status: true,
                    category: true,
                    batchNumber: true,
                    expiryDate: true,
                    location: true,
                  },
                },
              },
            },
          },
          orderBy: {
            createdAt: "desc",
          },
          take: 5,
        },
      },
      orderBy: {
        name: "asc",
      },
      take: limit,
    })

    return patients.map((patient) => ({
      id: patient.id,
      name: patient.name,
      age: patient.age,
      gender: patient.gender,
      phone: patient.phone,
      address: patient.address,
      condition: patient.condition,
      status: patient.status,
      allergies: patient.allergies || [],
      bloodType: patient.bloodType,
      emergencyContact: patient.emergencyContact,
      emergencyPhone: patient.emergencyPhone,
      vitals:
        typeof patient.vitals === "object" && patient.vitals !== null
          ? (patient.vitals as { bp?: string; pulse?: string; temp?: string; weight?: string; height?: string })
          : { bp: "", pulse: "", temp: "", weight: "", height: "" },
      lastVisit: patient.lastVisit,
      nextAppointment: patient.nextAppointment,
      medications: patient.prescriptions.flatMap((prescription) =>
        prescription.items.map((item) => ({
          id: item.id,
          name: item.drug.drugName,
          dosage: item.dosage,
          frequency: item.frequency,
          duration: item.duration,
          instructions: item.instructions,
          drugInfo: {
            id: item.drug.id,
            currentStock: item.drug.currentStock,
            minStock: item.drug.minStock,
            status: item.drug.status,
            category: item.drug.category,
            batchNumber: item.drug.batchNumber,
            expiryDate: item.drug.expiryDate,
            location: item.drug.location,
          },
          prescriptionDate: prescription.createdAt,
        })),
      ),
      medicalHistory: [], // TODO: Implement when medical records table is available
      createdAt: patient.createdAt,
      updatedAt: patient.updatedAt,
    }))
  } catch (error) {
    console.error("Error searching patients:", error)
    throw new Error("Failed to search patients")
  }
}

// Get patient details with enhanced medication data
export async function getPatientDetails(patientId: string): Promise<PatientData | null> {
  try {
    const patient = await prisma.patient.findUnique({
      where: { id: patientId },
      include: {
        prescriptions: {
          include: {
            items: {
              include: {
                drug: {
                  select: {
                    id: true,
                    drugName: true,
                    currentStock: true,
                    minStock: true,
                    status: true,
                    category: true,
                    batchNumber: true,
                    expiryDate: true,
                    location: true,
                  },
                },
              },
            },
          },
          orderBy: {
            createdAt: "desc",
          },
        },
      },
    })

    if (!patient) return null

    return {
      id: patient.id,
      name: patient.name,
      age: patient.age,
      gender: patient.gender,
      phone: patient.phone,
      address: patient.address,
      condition: patient.condition,
      status: patient.status,
      allergies: patient.allergies || [],
      bloodType: patient.bloodType,
      emergencyContact: patient.emergencyContact,
      emergencyPhone: patient.emergencyPhone,
      vitals:
        typeof patient.vitals === "object" && patient.vitals !== null
          ? (patient.vitals as { bp?: string; pulse?: string; temp?: string; weight?: string; height?: string })
          : { bp: "", pulse: "", temp: "", weight: "", height: "" },
      lastVisit: patient.lastVisit,
      nextAppointment: patient.nextAppointment,
      medications: patient.prescriptions.flatMap((prescription) =>
        prescription.items.map((item) => ({
          id: item.id,
          name: item.drug.drugName,
          dosage: item.dosage,
          frequency: item.frequency,
          duration: item.duration,
          instructions: item.instructions,
          drugInfo: {
            id: item.drug.id,
            currentStock: item.drug.currentStock,
            minStock: item.drug.minStock,
            status: item.drug.status,
            category: item.drug.category,
            batchNumber: item.drug.batchNumber,
            expiryDate: item.drug.expiryDate,
            location: item.drug.location,
          },
          prescriptionDate: prescription.createdAt,
        })),
      ),
      medicalHistory: [], // TODO: Implement when medical records table is available
      createdAt: patient.createdAt,
      updatedAt: patient.updatedAt,
    }
  } catch (error) {
    console.error("Error fetching patient details:", error)
    throw new Error("Failed to fetch patient details")
  }
}

// Create prescription with proper drug inventory validation
export async function createPrescription(data: CreatePrescriptionData): Promise<PrescriptionData> {
  try {
    // Get or create doctor by username
    const doctorId = await getOrCreateDoctorByUsername(data.doctorUsername)
    console.log(`Creating prescription for doctor: ${data.doctorUsername} (ID: ${doctorId})`)

    // First, validate all drugs exist in the inventory and check stock
    const drugPromises = data.medications.map(async (med) => {
      let drug = await prisma.drugInventory.findFirst({
        where: { drugName: { equals: med.drugName, mode: "insensitive" } },
      })

      if (!drug) {
        // Create drug if it doesn't exist
        drug = await prisma.drugInventory.create({
          data: {
            drugName: med.drugName,
            currentStock: 100, // Default stock
            minStock: 10,
            status: "normal",
          },
        })
        console.log(`Created new drug: ${med.drugName}`)
      }

      // Check if drug is available
      if (drug.currentStock <= 0) {
        console.warn(`Drug ${drug.drugName} is out of stock but allowing prescription`)
        // Don't throw error, just warn - allow prescription even if out of stock
      }

      // Check if drug is near expiry (if expiry date exists)
      if (drug.expiryDate && drug.expiryDate < new Date()) {
        console.warn(`Drug ${drug.drugName} has expired but allowing prescription`)
        // Don't throw error, just warn - allow prescription even if expired
      }

      return drug
    })

    const drugs = await Promise.all(drugPromises)

    // Create prescription with items
    const prescription = await prisma.prescription.create({
      data: {
        patientId: data.patientId,
        doctorId: doctorId, // Use the resolved doctorId
        notes: data.notes,
        status: "Pending",
        items: {
          create: data.medications.map((med, index) => ({
            drugId: drugs[index].id,
            dosage: med.dosage,
            frequency: med.frequency,
            duration: med.duration,
            instructions: med.instructions,
          })),
        },
      },
      include: {
        patient: {
          select: {
            name: true,
            age: true,
          },
        },
        items: {
          include: {
            drug: {
              select: {
                id: true,
                drugName: true,
                currentStock: true,
                minStock: true,
                status: true,
                category: true,
                batchNumber: true,
                expiryDate: true,
                location: true,
              },
            },
          },
        },
      },
    })

    // Update patient's last visit
    await prisma.patient.update({
      where: { id: data.patientId },
      data: {
        lastVisit: new Date(),
      },
    })

    console.log(`Prescription created successfully: ${prescription.id}`)
    revalidatePath("/doctor")

    return {
      id: prescription.id,
      patientId: prescription.patientId,
      doctorId: prescription.doctorId,
      status: prescription.status,
      notes: prescription.notes,
      patient: prescription.patient,
      items: prescription.items.map((item) => ({
        id: item.id,
        drugId: item.drugId,
        dosage: item.dosage,
        frequency: item.frequency,
        duration: item.duration,
        instructions: item.instructions,
        drug: item.drug,
      })),
      createdAt: prescription.createdAt,
    }
  } catch (error) {
    console.error("Error creating prescription:", error)
    throw new Error(`Failed to create prescription: ${error instanceof Error ? error.message : "Unknown error"}`)
  }
}

// Get doctor's prescriptions with enhanced drug data
export async function getDoctorPrescriptions(doctorUsername: string, limit = 50): Promise<PrescriptionData[]> {
  try {
    const doctorId = await getOrCreateDoctorByUsername(doctorUsername)

    const prescriptions = await prisma.prescription.findMany({
      where: { doctorId },
      include: {
        patient: {
          select: {
            name: true,
            age: true,
          },
        },
        items: {
          include: {
            drug: {
              select: {
                id: true,
                drugName: true,
                currentStock: true,
                minStock: true,
                status: true,
                category: true,
                batchNumber: true,
                expiryDate: true,
                location: true,
              },
            },
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
      take: limit,
    })

    return prescriptions.map((prescription) => ({
      id: prescription.id,
      patientId: prescription.patientId,
      doctorId: prescription.doctorId,
      status: prescription.status,
      notes: prescription.notes,
      patient: prescription.patient,
      items: prescription.items.map((item) => ({
        id: item.id,
        drugId: item.drugId,
        dosage: item.dosage,
        frequency: item.frequency,
        duration: item.duration,
        instructions: item.instructions,
        drug: item.drug,
      })),
      createdAt: prescription.createdAt,
    }))
  } catch (error) {
    console.error("Error fetching doctor prescriptions:", error)
    throw new Error("Failed to fetch prescriptions")
  }
}

// Update appointment status
export async function updateAppointmentStatus(appointmentId: string, status: string): Promise<boolean> {
  try {
    await prisma.appointment.update({
      where: { id: appointmentId },
      data: { status },
    })

    revalidatePath("/doctor")
    return true
  } catch (error) {
    console.error("Error updating appointment status:", error)
    throw new Error("Failed to update appointment status")
  }
}

// Get doctor statistics
export async function getDoctorStats(doctorUsername: string) {
  try {
    const doctorId = await getOrCreateDoctorByUsername(doctorUsername)

    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)

    const [todayAppointments, totalPatients, pendingPrescriptions, completedAppointments] = await Promise.all([
      prisma.appointment.count({
        where: {
          doctorId,
          date: {
            gte: today,
            lt: tomorrow,
          },
        },
      }),
      // Count all active patients in the system, not just doctor's patients
      prisma.patient.count({
        where: {
          status: "Active",
        },
      }),
      prisma.prescription.count({
        where: {
          doctorId,
          status: "Pending",
        },
      }),
      prisma.appointment.count({
        where: {
          doctorId,
          date: {
            gte: today,
            lt: tomorrow,
          },
          status: "Completed",
        },
      }),
    ])

    return {
      todayAppointments,
      totalPatients,
      pendingPrescriptions,
      completedAppointments,
    }
  } catch (error) {
    console.error("Error fetching doctor stats:", error)
    throw new Error("Failed to fetch doctor statistics")
  }
}

// Get available drugs with enhanced inventory information
export async function getAvailableDrugs(query?: string): Promise<
  {
    id: string
    drugName: string
    currentStock: number
    minStock: number
    status: string
    category?: string | null
    expiryDate?: Date | null
    location: string
  }[]
> {
  try {
    const drugs = await prisma.drugInventory.findMany({
      where: {
        AND: [
          query
            ? {
                drugName: {
                  contains: query,
                  mode: "insensitive",
                },
              }
            : {},
          {
            OR: [
              { expiryDate: null }, // No expiry date
              { expiryDate: { gt: new Date() } }, // Not expired
            ],
          },
        ],
      },
      select: {
        id: true,
        drugName: true,
        currentStock: true,
        minStock: true,
        status: true,
        category: true,
        expiryDate: true,
        location: true,
      },
      orderBy: [
        { currentStock: "desc" }, // Show drugs with stock first
        { status: "asc" }, // Show normal status first
        { drugName: "asc" },
      ],
      take: 100, // Increased limit to show more options
    })

    return drugs
  } catch (error) {
    console.error("Error fetching available drugs:", error)
    throw new Error("Failed to fetch available drugs")
  }
}

// Get all drugs for selection (including those that might be added manually)
export async function getAllDrugsForSelection(query?: string): Promise<
  {
    id: string
    drugName: string
    currentStock: number
    minStock: number
    status: string
    category?: string | null
    expiryDate?: Date | null
    location: string
    isAvailable: boolean
  }[]
> {
  try {
    const drugs = await prisma.drugInventory.findMany({
      where: query
        ? {
            drugName: {
              contains: query,
              mode: "insensitive",
            },
          }
        : {},
      select: {
        id: true,
        drugName: true,
        currentStock: true,
        minStock: true,
        status: true,
        category: true,
        expiryDate: true,
        location: true,
      },
      orderBy: [
        { currentStock: "desc" }, // Show drugs with stock first
        { drugName: "asc" },
      ],
      take: 100,
    })

    return drugs.map((drug) => ({
      ...drug,
      isAvailable: drug.currentStock > 0 && (!drug.expiryDate || drug.expiryDate > new Date()),
    }))
  } catch (error) {
    console.error("Error fetching all drugs:", error)
    throw new Error("Failed to fetch drugs")
  }
}
