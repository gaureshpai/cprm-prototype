"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import { AuthContextType, User } from "@/lib/interfaces"

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    console.log("AuthProvider: Checking for existing session")
    const savedUser = localStorage.getItem("udal_user")
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser)
        console.log("AuthProvider: Found saved user:", parsedUser)

        // Debug the user object structure
        console.log("AuthProvider: User ID:", parsedUser.id)
        console.log("AuthProvider: Username:", parsedUser.username)
        console.log("AuthProvider: User object keys:", Object.keys(parsedUser))

        // Validate that we have a proper user ID (should be a cuid, not username)
        if (!parsedUser.id || parsedUser.id === parsedUser.username) {
          console.warn("AuthProvider: Invalid user ID detected - ID matches username or is missing")
          console.warn("AuthProvider: This might cause foreign key constraint errors")
        }

        setUser(parsedUser)
      } catch (error) {
        console.error("AuthProvider: Error parsing saved user:", error)
        localStorage.removeItem("udal_user")
      }
    } else {
      console.log("AuthProvider: No saved user found")
    }
    setIsLoading(false)
  }, [])

  const login = (userData: User) => {
    console.log("AuthContext: Login called with:", userData)

    // Debug the incoming user data
    console.log("AuthContext: Incoming user ID:", userData.id)
    console.log("AuthContext: Incoming username:", userData.username)
    console.log("AuthContext: Incoming user object keys:", Object.keys(userData))

    // Validate the user data before saving
    if (!userData.id) {
      console.error("AuthContext: ERROR - No user ID provided!")
      throw new Error("Invalid user data: Missing user ID")
    }

    if (userData.id === userData.username) {
      console.error("AuthContext: ERROR - User ID is the same as username!")
      console.error("AuthContext: This will cause foreign key constraint violations")
      throw new Error("Invalid user data: User ID cannot be the same as username")
    }

    // Check if ID looks like a valid cuid (starts with 'c' and has proper length)
    if (!userData.id.startsWith('c') || userData.id.length < 20) {
      console.warn("AuthContext: WARNING - User ID doesn't look like a valid cuid:", userData.id)
    }

    setUser(userData)
    localStorage.setItem("udal_user", JSON.stringify(userData))
    console.log("AuthContext: User set and localStorage updated")
  }

  const logout = () => {
    console.log("AuthContext: Logout called")
    setUser(null)
    localStorage.removeItem("udal_user")
    router.push("/login")
  }

  useEffect(() => {
    console.log("AuthContext: User state changed:", user)
    if (user) {
      console.log("AuthContext: Current user ID:", user.id)
      console.log("AuthContext: Current username:", user.name)
    }
  }, [user])

  return <AuthContext.Provider value={{ user, login, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
