import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function GET() {
  try {
    await prisma.$connect()
    await prisma.$queryRaw`SELECT 1`
    await prisma.$disconnect()

    return NextResponse.json({ status: "healthy", database: "connected" })
  } catch (error) {
    await prisma.$disconnect()

    return NextResponse.json({ status: "unhealthy", database: "disconnected", error: error.message }, { status: 503 })
  }
}
