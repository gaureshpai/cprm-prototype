import { type NextRequest, NextResponse } from "next/server"
import { DisplayService } from "@/lib/display-service"

interface RouteParams {
  params: Promise<{ id: string }>
}

export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params
    const data = await DisplayService.getDisplayData(id)

    return NextResponse.json(data)
  } catch (error) {
    console.error("Error in GET /api/displays/[id]/data:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
