import { type NextRequest, NextResponse } from "next/server"
import { DisplayService } from "@/lib/display-service"

interface RouteParams {
  params: Promise<{ id: string }>
}

export async function POST(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params
    const result = await DisplayService.restartDisplay(id)

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 })
    }

    return NextResponse.json({ display: result.data })
  } catch (error) {
    console.error("Error in POST /api/displays/[id]/restart:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
