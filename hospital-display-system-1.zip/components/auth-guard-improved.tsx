"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAuth } from "@/hooks/use-auth-improved"
import { Loader2, AlertTriangle, Lock } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"

interface AuthGuardProps {
  children: React.ReactNode
  allowedRoles?: string[]
  requiredPermissions?: string[]
  fallbackPath?: string
  showUnauthorized?: boolean
}

export function AuthGuard({
  children,
  allowedRoles = [],
  requiredPermissions = [],
  fallbackPath = "/login",
  showUnauthorized = true,
}: AuthGuardProps) {
  const { user, isLoading, isAuthenticated, hasRole, hasPermission, logout } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [isChecking, setIsChecking] = useState(true)

  useEffect(() => {
    const checkAuth = async () => {
      if (isLoading) return

      console.log("🛡️ AuthGuard: Checking authentication for:", pathname)

      // Not authenticated
      if (!isAuthenticated) {
        console.log("❌ AuthGuard: User not authenticated, redirecting to:", fallbackPath)
        router.push(`${fallbackPath}?redirect=${encodeURIComponent(pathname)}`)
        return
      }

      // Check role requirements
      if (allowedRoles.length > 0 && !hasRole(allowedRoles)) {
        console.log("❌ AuthGuard: User role not allowed:", user?.role, "Required:", allowedRoles)
        setIsChecking(false)
        return
      }

      // Check permission requirements
      if (requiredPermissions.length > 0) {
        const hasAllPermissions = requiredPermissions.every((permission) => hasPermission(permission))
        if (!hasAllPermissions) {
          console.log("❌ AuthGuard: User missing required permissions:", requiredPermissions)
          setIsChecking(false)
          return
        }
      }

      console.log("✅ AuthGuard: Access granted")
      setIsChecking(false)
    }

    checkAuth()
  }, [
    isLoading,
    isAuthenticated,
    user,
    allowedRoles,
    requiredPermissions,
    hasRole,
    hasPermission,
    router,
    pathname,
    fallbackPath,
  ])

  // Show loading spinner while checking
  if (isLoading || isChecking) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Verifying access...</p>
        </div>
      </div>
    )
  }

  // Show unauthorized message if user doesn't have access
  if (
    isAuthenticated &&
    ((allowedRoles.length > 0 && !hasRole(allowedRoles)) ||
      (requiredPermissions.length > 0 && !requiredPermissions.every((permission) => hasPermission(permission))))
  ) {
    if (!showUnauthorized) {
      router.push("/unauthorized")
      return null
    }

    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50 p-4">
        <div className="max-w-md w-full">
          <Alert className="border-red-200 bg-red-50">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription className="text-red-800">
              <div className="space-y-3">
                <div>
                  <h3 className="font-semibold">Access Denied</h3>
                  <p className="text-sm mt-1">You don't have permission to access this page.</p>
                </div>

                {allowedRoles.length > 0 && (
                  <div>
                    <p className="text-sm">
                      <strong>Required role:</strong> {allowedRoles.join(", ")}
                    </p>
                    <p className="text-sm">
                      <strong>Your role:</strong> {user?.role || "Unknown"}
                    </p>
                  </div>
                )}

                {requiredPermissions.length > 0 && (
                  <div>
                    <p className="text-sm">
                      <strong>Required permissions:</strong> {requiredPermissions.join(", ")}
                    </p>
                  </div>
                )}

                <div className="flex space-x-2 pt-2">
                  <Button variant="outline" size="sm" onClick={() => router.back()} className="flex-1">
                    Go Back
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => logout()} className="flex-1">
                    <Lock className="h-3 w-3 mr-1" />
                    Logout
                  </Button>
                </div>
              </div>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    )
  }

  // User is authenticated and authorized
  return <>{children}</>
}
