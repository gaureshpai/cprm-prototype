"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Database, Wifi, WifiOff } from "lucide-react"

export function DatabaseStatus() {
  const [isOnline, setIsOnline] = useState<boolean | null>(null)

  useEffect(() => {
    const checkDatabaseStatus = async () => {
      try {
        const response = await fetch("/api/health/database")
        setIsOnline(response.ok)
      } catch (error) {
        setIsOnline(false)
      }
    }

    checkDatabaseStatus()
    const interval = setInterval(checkDatabaseStatus, 30000) // Check every 30 seconds

    return () => clearInterval(interval)
  }, [])

  if (isOnline === null) {
    return (
      <Badge variant="outline" className="flex items-center space-x-1">
        <Database className="h-3 w-3" />
        <span>Checking...</span>
      </Badge>
    )
  }

  return (
    <Badge
      className={`flex items-center space-x-1 ${
        isOnline ? "bg-green-100 text-green-800 border-green-200" : "bg-yellow-100 text-yellow-800 border-yellow-200"
      }`}
    >
      {isOnline ? (
        <>
          <Wifi className="h-3 w-3" />
          <span>Database Online</span>
        </>
      ) : (
        <>
          <WifiOff className="h-3 w-3" />
          <span>Mock Mode</span>
        </>
      )}
    </Badge>
  )
}
