import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function monitorDisplayStatus() {
  try {
    console.log("Running display status monitor...")

    // Find displays that haven't sent a heartbeat in the last 45 seconds (more aggressive)
    const fortyFiveSecondsAgo = new Date(Date.now() - 45 * 1000)

    // Update displays that haven't sent a heartbeat to offline
    const result = await prisma.display.updateMany({
      where: {
        status: "online",
        lastUpdate: {
          lt: fortyFiveSecondsAgo,
        },
      },
      data: {
        status: "offline",
      },
    })

    if (result.count > 0) {
      console.log(`Updated ${result.count} displays to offline status`)
    }

    await prisma.$disconnect()
    return result.count
  } catch (error) {
    console.error("Error monitoring display status:", error)
    await prisma.$disconnect()
    throw error
  }
}
