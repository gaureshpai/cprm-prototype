"use server"

import { PrismaClient } from "@prisma/client"
import type { Role } from "@prisma/client"

const prisma = new PrismaClient()

export interface CreateUserData {
  username: string
  name: string
  email?: string
  role: Role
  department?: string
}

export interface UpdateUserData {
  name?: string
  email?: string
  department?: string
  role?: Role
  status?: string
}

export interface UserWithStats {
  id: string
  username: string
  name: string
  email?: string | null
  role: Role
  department?: string | null
  status: string
  createdAt: Date
  updatedAt: Date
  permissions: any
}

export const userOperations = {
  // Find all users
  async findAll(): Promise<UserWithStats[]> {
    try {
      const users = await prisma.user.findMany({
        orderBy: { createdAt: "desc" },
      })

      await prisma.$disconnect()
      return users
    } catch (error) {
      console.error("Error finding all users:", error)
      await prisma.$disconnect()
      throw new Error("Failed to fetch users")
    }
  },

  // Find user by ID
  async findById(id: string): Promise<UserWithStats | null> {
    try {
      const user = await prisma.user.findUnique({
        where: { id },
      })

      await prisma.$disconnect()
      return user
    } catch (error) {
      console.error("Error finding user by ID:", error)
      await prisma.$disconnect()
      throw new Error("Failed to fetch user")
    }
  },

  // Find user by username
  async findByUsername(username: string): Promise<UserWithStats | null> {
    try {
      const user = await prisma.user.findUnique({
        where: { username },
      })

      await prisma.$disconnect()
      return user
    } catch (error) {
      console.error("Error finding user by username:", error)
      await prisma.$disconnect()
      throw new Error("Failed to fetch user")
    }
  },

  // Create new user
  async create(data: CreateUserData): Promise<UserWithStats> {
    try {
      // Check if username already exists
      const existingUser = await prisma.user.findUnique({
        where: { username: data.username },
      })

      if (existingUser) {
        await prisma.$disconnect()
        throw new Error("Username already exists")
      }

      // Check if email already exists (if provided)
      if (data.email) {
        const existingEmail = await prisma.user.findUnique({
          where: { email: data.email },
        })

        if (existingEmail) {
          await prisma.$disconnect()
          throw new Error("Email already exists")
        }
      }

      const user = await prisma.user.create({
        data: {
          username: data.username,
          name: data.name,
          email: data.email,
          role: data.role,
          department: data.department,
          status: "ACTIVE",
          permissions: getDefaultPermissions(data.role),
        },
      })

      await prisma.$disconnect()
      return user
    } catch (error) {
      console.error("Error creating user:", error)
      await prisma.$disconnect()
      throw error
    }
  },

  // Update user
  async update(id: string, data: UpdateUserData): Promise<UserWithStats> {
    try {
      // Check if email already exists (if being updated)
      if (data.email) {
        const existingEmail = await prisma.user.findFirst({
          where: {
            email: data.email,
            NOT: { id },
          },
        })

        if (existingEmail) {
          await prisma.$disconnect()
          throw new Error("Email already exists")
        }
      }

      const user = await prisma.user.update({
        where: { id },
        data: {
          ...data,
          updatedAt: new Date(),
        },
      })

      await prisma.$disconnect()
      return user
    } catch (error) {
      console.error("Error updating user:", error)
      await prisma.$disconnect()
      throw error
    }
  },

  // Delete user (soft delete by setting status to INACTIVE)
  async deleteUser(id: string): Promise<boolean> {
    try {
      // Check if user has any dependencies
      const userDependencies = await checkUserDependencies(id)

      if (userDependencies.hasAppointments || userDependencies.hasPrescriptions) {
        // Soft delete - set status to INACTIVE
        await prisma.user.update({
          where: { id },
          data: {
            status: "INACTIVE",
            updatedAt: new Date(),
          },
        })
      } else {
        // Hard delete if no dependencies
        await prisma.user.delete({
          where: { id },
        })
      }

      await prisma.$disconnect()
      return true
    } catch (error) {
      console.error("Error deleting user:", error)
      await prisma.$disconnect()
      throw new Error("Failed to delete user")
    }
  },

  // Get user statistics
  async getStats() {
    try {
      const totalUsers = await prisma.user.count({
        where: { status: "ACTIVE" },
      })

      const usersByRole = await prisma.user.groupBy({
        by: ["role"],
        where: { status: "ACTIVE" },
        _count: {
          role: true,
        },
      })

      const usersByDepartment = await prisma.user.groupBy({
        by: ["department"],
        where: {
          status: "ACTIVE",
          department: { not: null },
        },
        _count: {
          department: true,
        },
      })

      await prisma.$disconnect()

      return {
        total: totalUsers,
        byRole: usersByRole.reduce(
          (acc, item) => {
            acc[item.role] = item._count.role
            return acc
          },
          {} as Record<Role, number>,
        ),
        byDepartment: usersByDepartment.reduce(
          (acc, item) => {
            if (item.department) {
              acc[item.department] = item._count.department
            }
            return acc
          },
          {} as Record<string, number>,
        ),
      }
    } catch (error) {
      console.error("Error getting user stats:", error)
      await prisma.$disconnect()
      throw new Error("Failed to get user statistics")
    }
  },

  // Activate/Deactivate user
  async toggleStatus(id: string): Promise<UserWithStats> {
    try {
      const user = await prisma.user.findUnique({
        where: { id },
      })

      if (!user) {
        await prisma.$disconnect()
        throw new Error("User not found")
      }

      const newStatus = user.status === "ACTIVE" ? "INACTIVE" : "ACTIVE"

      const updatedUser = await prisma.user.update({
        where: { id },
        data: {
          status: newStatus,
          updatedAt: new Date(),
        },
      })

      await prisma.$disconnect()
      return updatedUser
    } catch (error) {
      console.error("Error toggling user status:", error)
      await prisma.$disconnect()
      throw error
    }
  },
}

// Helper function to check user dependencies
async function checkUserDependencies(userId: string) {
  try {
    const [appointmentCount, prescriptionCount] = await Promise.all([
      prisma.appointment.count({
        where: { doctorId: userId },
      }),
      prisma.prescription.count({
        where: { doctorId: userId },
      }),
    ])

    return {
      hasAppointments: appointmentCount > 0,
      hasPrescriptions: prescriptionCount > 0,
    }
  } catch (error) {
    console.error("Error checking user dependencies:", error)
    return {
      hasAppointments: false,
      hasPrescriptions: false,
    }
  }
}

// Helper function to get default permissions based on role
function getDefaultPermissions(role: Role): any {
  const permissions = {
    ADMIN: [
      "user_management",
      "display_management",
      "content_management",
      "emergency_alerts",
      "system_settings",
      "analytics",
    ],
    DOCTOR: ["patient_management", "appointments", "prescriptions", "medical_records"],
    NURSE: ["patient_care", "appointments", "medication_administration"],
    TECHNICIAN: ["equipment_management", "maintenance", "technical_support"],
    PHARMACIST: ["drug_inventory", "prescriptions", "medication_dispensing"],
    PATIENT: ["view_appointments", "view_prescriptions", "personal_records"],
  }

  return permissions[role] || []
}

// Export individual functions for backward compatibility
export const {
  findAll: findAllUsers,
  findById: findUserById,
  findByUsername: findUserByUsername,
  create: createUser,
  update: updateUser,
  deleteUser,
  getStats: getUserStats,
  toggleStatus: toggleUserStatus,
} = userOperations
