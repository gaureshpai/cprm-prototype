"use server"

import { PrismaClient } from "@prisma/client"

// Try to import both real and mock actions
import * as realActions from "./user-actions"
import * as mockActions from "./user-actions-mock"

const prisma = new PrismaClient()

// Test if database is available
async function isDatabaseAvailable(): Promise<boolean> {
  try {
    await prisma.$connect()
    await prisma.$queryRaw`SELECT 1`
    await prisma.$disconnect()
    return true
  } catch (error) {
    console.warn("Database not available, using mock data:", error.message)
    await prisma.$disconnect()
    return false
  }
}

// Smart wrapper that chooses between real and mock actions
export async function getAllUsersAction() {
  const dbAvailable = await isDatabaseAvailable()
  if (dbAvailable) {
    return realActions.getAllUsersAction()
  } else {
    return mockActions.getAllUsersAction()
  }
}

export async function getUserByIdAction(id: string) {
  const dbAvailable = await isDatabaseAvailable()
  if (dbAvailable) {
    return realActions.getUserByIdAction(id)
  } else {
    return mockActions.getUserByIdAction(id)
  }
}

export async function createUserAction(formData: FormData) {
  const dbAvailable = await isDatabaseAvailable()
  if (dbAvailable) {
    return realActions.createUserAction(formData)
  } else {
    return mockActions.createUserAction(formData)
  }
}

export async function updateUserAction(id: string, formData: FormData) {
  const dbAvailable = await isDatabaseAvailable()
  if (dbAvailable) {
    return realActions.updateUserAction(id, formData)
  } else {
    return mockActions.updateUserAction(id, formData)
  }
}

export async function deleteUserAction(id: string) {
  const dbAvailable = await isDatabaseAvailable()
  if (dbAvailable) {
    return realActions.deleteUserAction(id)
  } else {
    return mockActions.deleteUserAction(id)
  }
}

export async function toggleUserStatusAction(id: string) {
  const dbAvailable = await isDatabaseAvailable()
  if (dbAvailable) {
    return realActions.toggleUserStatusAction(id)
  } else {
    return mockActions.toggleUserStatusAction(id)
  }
}

export async function getUserStatsAction() {
  const dbAvailable = await isDatabaseAvailable()
  if (dbAvailable) {
    return realActions.getUserStatsAction()
  } else {
    return mockActions.getUserStatsAction()
  }
}

// Re-export types
export type { UserWithStats, UserActionResponse, CreateUserData, UpdateUserData } from "./user-actions"
