"use client"

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react"
import { useRouter } from "next/navigation"
import type { AuthContextType, User, LoginCredentials } from "@/lib/interfaces"
import { authenticateUser, refreshUserData, logoutUser } from "@/lib/auth-service"
import {
  secureStorage,
  AUTH_STORAGE_KEY,
  validateUser,
  checkPermission,
  checkRole,
  isSessionValid,
  refreshSession,
} from "@/lib/auth-utils"

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  // Initialize auth state
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        console.log("🔐 AuthProvider: Initializing authentication")

        const savedUser = secureStorage.get(AUTH_STORAGE_KEY)

        if (savedUser && validateUser(savedUser)) {
          console.log("✅ AuthProvider: Found valid saved user:", savedUser.username)

          // Check if session is still valid
          if (isSessionValid(savedUser)) {
            setUser(savedUser)
            console.log("✅ AuthProvider: Session is valid")
          } else {
            console.log("⚠️ AuthProvider: Session expired, clearing storage")
            secureStorage.clear()
          }
        } else {
          console.log("ℹ️ AuthProvider: No valid saved user found")
        }
      } catch (error) {
        console.error("❌ AuthProvider: Error initializing auth:", error)
        secureStorage.clear()
      } finally {
        setIsLoading(false)
      }
    }

    initializeAuth()
  }, [])

  // Auto-refresh session before expiry
  useEffect(() => {
    if (!user || !user.sessionExpiry) return

    const expiryTime = new Date(user.sessionExpiry).getTime()
    const currentTime = Date.now()
    const timeUntilExpiry = expiryTime - currentTime
    const refreshTime = Math.max(timeUntilExpiry - 5 * 60 * 1000, 60 * 1000) // Refresh 5 minutes before expiry, but at least 1 minute

    if (refreshTime > 0) {
      const refreshTimer = setTimeout(() => {
        console.log(" AuthProvider: Auto-refreshing session")
        refreshUser()
      }, refreshTime)

      return () => clearTimeout(refreshTimer)
    }
  }, [user])

  // Login function
  const login = useCallback(
    async (credentials: LoginCredentials): Promise<void> => {
      try {
        console.log("🔐 AuthProvider: Login attempt for:", credentials.username)
        setIsLoading(true)

        const response = await authenticateUser(credentials)

        if (response.success && response.user) {
          const userWithSession = refreshSession(response.user, credentials.rememberMe)
          setUser(userWithSession)
          secureStorage.set(AUTH_STORAGE_KEY, userWithSession, credentials.rememberMe)

          console.log("✅ AuthProvider: Login successful")

          // Redirect based on role
          const redirectPath = getRedirectPath(userWithSession.role)
          router.push(redirectPath)
        } else {
          console.error("❌ AuthProvider: Login failed:", response.error)
          throw new Error(response.error?.message || "Login failed")
        }
      } catch (error) {
        console.error("❌ AuthProvider: Login error:", error)
        throw error
      } finally {
        setIsLoading(false)
      }
    },
    [router],
  )

  // Logout function
  const logout = useCallback(async (): Promise<void> => {
    try {
      console.log("🚪 AuthProvider: Logout initiated")
      setIsLoading(true)

      if (user) {
        await logoutUser(user.id)
      }

      setUser(null)
      secureStorage.clear()

      console.log("✅ AuthProvider: Logout successful")
      router.push("/login")
    } catch (error) {
      console.error("❌ AuthProvider: Logout error:", error)
      // Still clear local state even if server logout fails
      setUser(null)
      secureStorage.clear()
      router.push("/login")
    } finally {
      setIsLoading(false)
    }
  }, [user, router])

  // Refresh user data
  const refreshUser = useCallback(async (): Promise<void> => {
    if (!user) return

    try {
      console.log("🔄 AuthProvider: Refreshing user data")

      const response = await refreshUserData(user.id)

      if (response.success && response.user) {
        const refreshedUser = refreshSession(response.user)
        setUser(refreshedUser)
        secureStorage.set(AUTH_STORAGE_KEY, refreshedUser)
        console.log("✅ AuthProvider: User data refreshed")
      } else {
        console.error("❌ AuthProvider: Failed to refresh user data")
        await logout()
      }
    } catch (error) {
      console.error("❌ AuthProvider: Error refreshing user:", error)
      await logout()
    }
  }, [user, logout])

  // Update user data locally
  const updateUser = useCallback(
    (updates: Partial<User>): void => {
      if (!user) return

      const updatedUser = { ...user, ...updates }
      setUser(updatedUser)
      secureStorage.set(AUTH_STORAGE_KEY, updatedUser)
      console.log("✅ AuthProvider: User data updated locally")
    },
    [user],
  )

  // Permission checking
  const hasPermission = useCallback(
    (permission: string): boolean => {
      return checkPermission(user, permission)
    },
    [user],
  )

  // Role checking
  const hasRole = useCallback(
    (roles: string | string[]): boolean => {
      return checkRole(user, roles)
    },
    [user],
  )

  // Computed values
  const isAuthenticated = Boolean(user && isSessionValid(user))

  // Debug logging
  useEffect(() => {
    console.log("🔍 AuthProvider: Auth state changed:", {
      isAuthenticated,
      user: user ? { id: user.id, username: user.username, role: user.role } : null,
      isLoading,
    })
  }, [user, isAuthenticated, isLoading])

  const contextValue: AuthContextType = {
    user,
    login,
    logout,
    isLoading,
    isAuthenticated,
    hasPermission,
    hasRole,
    refreshUser,
    updateUser,
  }

  return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

// Helper function to determine redirect path based on role
function getRedirectPath(role: string): string {
  switch (role) {
    case "ADMIN":
      return "/admin"
    case "DOCTOR":
      return "/doctor/dashboard"
    case "NURSE":
      return "/nurse/dashboard"
    case "TECHNICIAN":
      return "/technician/dashboard"
    case "PHARMACIST":
      return "/pharmacy/dashboard"
    default:
      return "/dashboard"
  }
}
