import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function inspectDatabaseSchema() {
  try {
    console.log("🔍 Inspecting actual database schema...")

    // Get all table names
    const tables = await prisma.$queryRaw`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      ORDER BY table_name;
    `

    console.log("\n📋 Available tables:")
    console.log(tables)

    // Check specific tables we're interested in
    const tablesToCheck = ["displays", "token_queue", "departments", "emergency_alerts", "drug_inventory"]

    for (const tableName of tablesToCheck) {
      try {
        console.log(`\n🔍 Checking table: ${tableName}`)

        const columns = await prisma.$queryRaw`
          SELECT column_name, data_type, is_nullable, column_default
          FROM information_schema.columns 
          WHERE table_schema = 'public' 
          AND table_name = ${tableName}
          ORDER BY ordinal_position;
        `

        if (Array.isArray(columns) && columns.length > 0) {
          console.log(`✅ Table ${tableName} exists with columns:`)
          columns.forEach((col: any) => {
            console.log(
              `  - ${col.column_name}: ${col.data_type} ${col.is_nullable === "YES" ? "(nullable)" : "(required)"}`,
            )
          })

          // Try to get a sample record
          try {
            const sampleQuery = `SELECT * FROM ${tableName} LIMIT 1`
            const sample = await prisma.$queryRawUnsafe(sampleQuery)
            if (Array.isArray(sample) && sample.length > 0) {
              console.log(`📄 Sample record from ${tableName}:`)
              console.log(JSON.stringify(sample[0], null, 2))
            } else {
              console.log(`📄 No data in ${tableName}`)
            }
          } catch (sampleError) {
            console.log(`⚠️ Could not get sample from ${tableName}:`, sampleError.message)
          }
        } else {
          console.log(`❌ Table ${tableName} does not exist or has no columns`)
        }
      } catch (error) {
        console.log(`❌ Error checking table ${tableName}:`, error.message)
      }
    }
  } catch (error) {
    console.error("❌ Error inspecting database schema:", error)
  } finally {
    await prisma.$disconnect()
  }
}

inspectDatabaseSchema()
