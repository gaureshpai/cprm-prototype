import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function seedMinimalData() {
  try {
    console.log("Seeding minimal data...")

    // Try to seed just displays first since we know that works
    console.log("Seeding displays...")
    const existingDisplays = await prisma.display.count()

    if (existingDisplays === 0) {
      await prisma.display.createMany({
        data: [
          {
            location: "Main Lobby",
            content: "Token Queue",
            status: "online",
            uptime: "2h 30m",
            lastUpdate: new Date(),
          },
          {
            location: "Emergency Ward",
            content: "Emergency Alerts",
            status: "online",
            uptime: "1h 15m",
            lastUpdate: new Date(),
          },
          {
            location: "Pharmacy",
            content: "Drug Inventory",
            status: "warning",
            uptime: "45m",
            lastUpdate: new Date(),
          },
        ],
      })
      console.log("✅ Displays seeded successfully!")
    } else {
      console.log("Displays already exist, skipping...")
    }

    // Try to create a single token queue entry to test the schema
    console.log("Testing token queue creation...")
    try {
      await prisma.tokenQueue.create({
        data: {
          tokenId: "T001",
          patientName: "Test Patient",
          status: "waiting",
          department: "General", // This field was missing in the previous attempt
        },
      })
      console.log("✅ Token queue test successful!")
    } catch (tokenError) {
      console.log("Token queue error:", tokenError.message)
      console.log("This helps us understand the required fields")
    }

    console.log("✅ Minimal data seeding completed!")
  } catch (error) {
    console.error("❌ Error seeding minimal data:", error)
  } finally {
    await prisma.$disconnect()
  }
}

seedMinimalData()
