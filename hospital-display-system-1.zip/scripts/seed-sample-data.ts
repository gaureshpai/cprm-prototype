import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function seedSampleData() {
  try {
    console.log("Seeding sample data...")

    // Seed token queue data
    await prisma.tokenQueue.createMany({
      data: [
        {
          id: "token1",
          status: "waiting",
          dept_id: "cardiology",
          patient_name: "John Doe",
          timestamp: new Date(),
          estimated_wait: 15,
        },
        {
          id: "token2",
          status: "in_progress",
          dept_id: "emergency",
          patient_name: "Jane Smith",
          timestamp: new Date(),
          estimated_wait: 5,
        },
        {
          id: "token3",
          status: "waiting",
          dept_id: "neurology",
          patient_name: "Bob Johnson",
          timestamp: new Date(),
          estimated_wait: 25,
        },
      ],
      skipDuplicates: true,
    })

    // Seed departments data
    await prisma.department.createMany({
      data: [
        {
          id: "dept1",
          location: "Ground Floor",
          department_name: "Cardiology",
          current_tokens: 5,
          avg_wait_time: 20,
        },
        {
          id: "dept2",
          location: "First Floor",
          department_name: "Emergency",
          current_tokens: 12,
          avg_wait_time: 10,
        },
        {
          id: "dept3",
          location: "Second Floor",
          department_name: "Neurology",
          current_tokens: 3,
          avg_wait_time: 30,
        },
      ],
      skipDuplicates: true,
    })

    // Seed emergency alerts data
    await prisma.emergencyAlert.createMany({
      data: [
        {
          id: "alert1",
          status: "active",
          timestamp: new Date(),
          department: "Emergency",
          code_type: "Code Blue",
          severity: "high",
        },
      ],
      skipDuplicates: true,
    })

    // Seed drug inventory data
    await prisma.drugInventory.createMany({
      data: [
        {
          id: "drug1",
          status: "critical",
          drug_name: "Paracetamol",
          stock_qty: 5,
          reorder_level: 50,
          category: "Pain Relief",
          last_updated: new Date(),
        },
        {
          id: "drug2",
          status: "critical",
          drug_name: "Insulin",
          stock_qty: 2,
          reorder_level: 20,
          category: "Diabetes",
          last_updated: new Date(),
        },
      ],
      skipDuplicates: true,
    })

    console.log("✅ Sample data seeded successfully!")
  } catch (error) {
    console.error("❌ Error seeding sample data:", error)
  } finally {
    await prisma.$disconnect()
  }
}

seedSampleData()
