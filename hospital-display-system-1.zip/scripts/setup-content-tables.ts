import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function setupContentTables() {
  try {
    console.log("Setting up content management tables...")

    // Create a default admin user if none exists
    const existingAdmin = await prisma.user.findFirst({
      where: { role: "ADMIN" },
    })

    if (!existingAdmin) {
      console.log("Creating default admin user...")
      await prisma.user.create({
        data: {
          username: "admin",
          email: "admin@hospital.com",
          name: "System Administrator",
          role: "ADMIN",
          status: "ACTIVE",
        },
      })
      console.log("✅ Default admin user created")
    } else {
      console.log("✅ Admin user already exists")
    }

    // Create some sample content items
    const existingContent = await prisma.contentItem.count()
    if (existingContent === 0) {
      console.log("Creating sample content items...")

      const admin = await prisma.user.findFirst({
        where: { role: "ADMIN" },
      })

      if (admin) {
        await prisma.contentItem.createMany({
          data: [
            {
              title: "Health Education: Hand Hygiene",
              type: "Educational",
              content: "Proper hand hygiene prevents infections. Wash hands for 20 seconds with soap and water.",
              createdBy: admin.id,
              active: true,
            },
            {
              title: "Department Staff Directory",
              type: "Information",
              content: "Contact information for all department staff and emergency contacts.",
              createdBy: admin.id,
              active: true,
            },
            {
              title: "Visiting Hours Information",
              type: "Information",
              content: "General visiting hours: 4:00 PM - 7:00 PM daily. ICU visiting hours: 2:00 PM - 4:00 PM.",
              createdBy: admin.id,
              active: true,
            },
          ],
        })
        console.log("✅ Sample content items created")
      }
    } else {
      console.log("✅ Content items already exist")
    }

    // Create some sample announcements
    const existingAnnouncements = await prisma.announcement.count()
    if (existingAnnouncements === 0) {
      console.log("Creating sample announcements...")

      const admin = await prisma.user.findFirst({
        where: { role: "ADMIN" },
      })

      if (admin) {
        await prisma.announcement.createMany({
          data: [
            {
              text: "Hospital visiting hours have been updated to 4:00 PM - 7:00 PM daily",
              createdBy: admin.id,
              priority: 2,
              active: true,
            },
            {
              text: "New COVID-19 vaccination drive starting next week. Please contact reception for appointments.",
              createdBy: admin.id,
              priority: 1,
              active: true,
            },
            {
              text: "Emergency department wait times are currently longer than usual. Please be patient.",
              createdBy: admin.id,
              priority: 3,
              active: true,
            },
          ],
        })
        console.log("✅ Sample announcements created")
      }
    } else {
      console.log("✅ Announcements already exist")
    }

    console.log("✅ Content management setup completed successfully!")
  } catch (error) {
    console.error("❌ Error setting up content tables:", error)
  } finally {
    await prisma.$disconnect()
  }
}

setupContentTables()
