-- Add missing fields to displays table if they don't exist
ALTER TABLE displays 
ADD COLUMN IF NOT EXISTS "isActive" BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS "config" JSONB DEFAULT '{}';

-- Update existing records
UPDATE displays 
SET "isActive" = true, "config" = '{}'
WHERE "isActive" IS NULL OR "config" IS NULL;

-- Fix token queue table field names if needed
ALTER TABLE token_queue 
RENAME COLUMN IF EXISTS "patient_name" TO "patientName",
ADD COLUMN IF NOT EXISTS "displayName" TEXT,
ADD COLUMN IF NOT EXISTS "department" TEXT DEFAULT 'General',
ADD COLUMN IF NOT EXISTS "priority" INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS "estimatedTime" TEXT;

-- Fix department table field names if needed
ALTER TABLE departments 
RENAME COLUMN IF EXISTS "department_name" TO "departmentName",
RENAME COLUMN IF EXISTS "current_tokens" TO "currentTokens";

-- Fix emergency alerts table field names if needed
ALTER TABLE emergency_alerts 
RENAME COLUMN IF EXISTS "code_type" TO "codeType",
ADD COLUMN IF NOT EXISTS "location" TEXT,
ADD COLUMN IF NOT EXISTS "message" TEXT,
ADD COLUMN IF NOT EXISTS "priority" INTEGER DEFAULT 1;

-- Fix drug inventory table field names if needed
ALTER TABLE drug_inventory 
RENAME COLUMN IF EXISTS "drug_name" TO "drugName",
RENAME COLUMN IF EXISTS "stock_qty" TO "currentStock",
RENAME COLUMN IF EXISTS "reorder_level" TO "minStock";
