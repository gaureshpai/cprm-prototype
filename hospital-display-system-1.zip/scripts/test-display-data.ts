import { getDisplayDataAction } from "@/lib/display-actions"

async function testDisplayData() {
  try {
    console.log("Testing display data fetching...")

    const data = await getDisplayDataAction("test-display-id")

    console.log("Display data structure:")
    console.log("Token Queue items:", data.tokenQueue.length)
    console.log("Departments:", data.departments.length)
    console.log("Emergency Alerts:", data.emergencyAlerts.length)
    console.log("Drug Inventory items:", data.drugInventory.length)

    if (data.tokenQueue.length > 0) {
      console.log("Sample token:", data.tokenQueue[0])
    }

    if (data.departments.length > 0) {
      console.log("Sample department:", data.departments[0])
    }

    console.log("✅ Display data test completed!")
  } catch (error) {
    console.error("❌ Error testing display data:", error)
  }
}

testDisplayData()
