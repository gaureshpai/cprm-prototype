-- Enhanced schema for doctor functionality
ALTER TABLE "Patient" ADD COLUMN IF NOT EXISTS "allergies" TEXT[];
ALTER TABLE "Patient" ADD COLUMN IF NOT EXISTS "bloodType" VARCHAR(10);
ALTER TABLE "Patient" ADD COLUMN IF NOT EXISTS "emergencyContact" VARCHAR(100);
ALTER TABLE "Patient" ADD COLUMN IF NOT EXISTS "emergencyPhone" VARCHAR(20);
ALTER TABLE "Patient" ADD COLUMN IF NOT EXISTS "medicalHistory" JSONB DEFAULT '[]';
ALTER TABLE "Patient" ADD COLUMN IF NOT EXISTS "vitals" JSONB DEFAULT '{}';
ALTER TABLE "Patient" ADD COLUMN IF NOT EXISTS "lastVisit" TIMESTAMP;
ALTER TABLE "Patient" ADD COLUMN IF NOT EXISTS "nextAppointment" TIMESTAMP;

-- Add diagnosis field to prescriptions
ALTER TABLE "Prescription" ADD COLUMN IF NOT EXISTS "diagnosis" TEXT;
ALTER TABLE "Prescription" ADD COLUMN IF NOT EXISTS "followUpDate" DATE;

-- Create medical records table
CREATE TABLE IF NOT EXISTS "MedicalRecord" (
  "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  "patientId" TEXT NOT NULL,
  "doctorId" TEXT NOT NULL,
  "visitDate" TIMESTAMP NOT NULL DEFAULT now(),
  "diagnosis" TEXT NOT NULL,
  "symptoms" TEXT[],
  "treatment" TEXT,
  "notes" TEXT,
  "vitals" JSONB DEFAULT '{}',
  "followUpRequired" BOOLEAN DEFAULT false,
  "followUpDate" DATE,
  "createdAt" TIMESTAMP DEFAULT now(),
  "updatedAt" TIMESTAMP DEFAULT now(),
  FOREIGN KEY ("patientId") REFERENCES "Patient"("id"),
  FOREIGN KEY ("doctorId") REFERENCES "User"("id")
);

-- Create doctor schedule table
CREATE TABLE IF NOT EXISTS "DoctorSchedule" (
  "id" TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  "doctorId" TEXT NOT NULL,
  "date" DATE NOT NULL,
  "startTime" TIME NOT NULL,
  "endTime" TIME NOT NULL,
  "isAvailable" BOOLEAN DEFAULT true,
  "maxPatients" INTEGER DEFAULT 20,
  "currentPatients" INTEGER DEFAULT 0,
  "notes" TEXT,
  "createdAt" TIMESTAMP DEFAULT now(),
  "updatedAt" TIMESTAMP DEFAULT now(),
  FOREIGN KEY ("doctorId") REFERENCES "User"("id")
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS "idx_medical_records_patient" ON "MedicalRecord"("patientId");
CREATE INDEX IF NOT EXISTS "idx_medical_records_doctor" ON "MedicalRecord"("doctorId");
CREATE INDEX IF NOT EXISTS "idx_medical_records_date" ON "MedicalRecord"("visitDate");
CREATE INDEX IF NOT EXISTS "idx_doctor_schedule_doctor_date" ON "DoctorSchedule"("doctorId", "date");
CREATE INDEX IF NOT EXISTS "idx_appointments_doctor_date" ON "Appointment"("doctorId", "date");
CREATE INDEX IF NOT EXISTS "idx_prescriptions_doctor" ON "Prescription"("doctorId");

-- Insert sample data for testing
INSERT INTO "Patient" ("id", "name", "age", "gender", "phone", "address", "condition", "status", "allergies", "bloodType", "emergencyContact", "emergencyPhone", "vitals", "lastVisit", "nextAppointment") VALUES
('pat_001', 'Rajesh Kumar', 45, 'Male', '+91-9876543210', '123 MG Road, Mangalore', 'Hypertension', 'Active', ARRAY['Penicillin', 'Shellfish'], 'O+', 'Sunita Kumar', '+91-9876543211', '{"bp": "140/90", "pulse": "78", "temp": "98.6°F", "weight": "75kg", "height": "5''8\""}', '2024-12-01 10:30:00', '2024-12-15 14:00:00'),
('pat_002', 'Priya Sharma', 32, 'Female', '+91-9876543212', '456 Car Street, Mangalore', 'Diabetes Type 2', 'Active', ARRAY['Sulfa drugs'], 'A+', 'Vikram Sharma', '+91-9876543213', '{"bp": "130/85", "pulse": "82", "temp": "98.4°F", "weight": "65kg", "height": "5''4\""}', '2024-12-02 11:15:00', '2024-12-16 10:30:00'),
('pat_003', 'Mohammed Ali', 28, 'Male', '+91-9876543214', '789 Bunder Road, Mangalore', 'Asthma', 'Active', ARRAY['Aspirin'], 'B+', 'Fatima Ali', '+91-9876543215', '{"bp": "120/80", "pulse": "75", "temp": "98.2°F", "weight": "70kg", "height": "5''7\""}', '2024-12-03 09:45:00', '2024-12-17 15:30:00'),
('pat_004', 'Lakshmi Nair', 55, 'Female', '+91-9876543216', '321 Kadri Hills, Mangalore', 'Arthritis', 'Active', ARRAY[], 'AB+', 'Suresh Nair', '+91-9876543217', '{"bp": "135/88", "pulse": "80", "temp": "98.8°F", "weight": "68kg", "height": "5''3\""}', '2024-12-04 14:20:00', '2024-12-18 11:00:00'),
('pat_005', 'Arjun Rao', 38, 'Male', '+91-9876543218', '654 Bejai, Mangalore', 'Migraine', 'Active', ARRAY['Latex'], 'O-', 'Meera Rao', '+91-9876543219', '{"bp": "125/82", "pulse": "72", "temp": "98.0°F", "weight": "72kg", "height": "5''9\""}', '2024-12-05 16:00:00', '2024-12-19 09:30:00')
ON CONFLICT ("id") DO NOTHING;

-- Insert sample appointments
INSERT INTO "Appointment" ("id", "patientId", "doctorId", "date", "time", "status", "type", "notes") VALUES
('app_001', 'pat_001', 'doc_001', '2024-12-10', '09:00', 'Scheduled', 'CONSULTATION', 'Regular checkup for hypertension'),
('app_002', 'pat_002', 'doc_001', '2024-12-10', '09:30', 'Scheduled', 'FOLLOW_UP', 'Diabetes management review'),
('app_003', 'pat_003', 'doc_001', '2024-12-10', '10:00', 'In Progress', 'CONSULTATION', 'Asthma symptoms worsening'),
('app_004', 'pat_004', 'doc_001', '2024-12-10', '10:30', 'Waiting', 'CONSULTATION', 'Joint pain assessment'),
('app_005', 'pat_005', 'doc_001', '2024-12-10', '11:00', 'Scheduled', 'FOLLOW_UP', 'Migraine treatment follow-up')
ON CONFLICT ("id") DO NOTHING;

-- Insert sample medical records
INSERT INTO "MedicalRecord" ("id", "patientId", "doctorId", "visitDate", "diagnosis", "symptoms", "treatment", "notes", "vitals", "followUpRequired", "followUpDate") VALUES
('rec_001', 'pat_001', 'doc_001', '2024-12-01 10:30:00', 'Essential Hypertension', ARRAY['Headache', 'Dizziness'], 'Prescribed Amlodipine 5mg', 'Patient responding well to medication', '{"bp": "140/90", "pulse": "78", "temp": "98.6°F"}', true, '2024-12-15'),
('rec_002', 'pat_002', 'doc_001', '2024-12-02 11:15:00', 'Type 2 Diabetes Mellitus', ARRAY['Increased thirst', 'Frequent urination'], 'Metformin 500mg twice daily', 'HbA1c levels improving', '{"bp": "130/85", "pulse": "82", "glucose": "180mg/dl"}', true, '2024-12-16'),
('rec_003', 'pat_003', 'doc_001', '2024-12-03 09:45:00', 'Bronchial Asthma', ARRAY['Shortness of breath', 'Wheezing'], 'Salbutamol inhaler as needed', 'Symptoms controlled with current medication', '{"bp": "120/80", "pulse": "75", "oxygen": "98%"}', false, NULL)
ON CONFLICT ("id") DO NOTHING;

-- Insert sample doctor schedule
INSERT INTO "DoctorSchedule" ("id", "doctorId", "date", "startTime", "endTime", "isAvailable", "maxPatients", "currentPatients") VALUES
('sch_001', 'doc_001', '2024-12-10', '09:00', '17:00', true, 20, 5),
('sch_002', 'doc_001', '2024-12-11', '09:00', '17:00', true, 20, 0),
('sch_003', 'doc_001', '2024-12-12', '09:00', '17:00', true, 20, 0)
ON CONFLICT ("id") DO NOTHING;
