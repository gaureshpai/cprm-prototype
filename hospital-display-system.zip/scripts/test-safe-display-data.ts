import { getDisplayDataAction } from "@/lib/display-actions-safe"

async function testSafeDisplayData() {
  try {
    console.log("Testing safe display data fetching...")

    const data = await getDisplayDataAction("test-display-id")

    console.log("\n📊 Final Results:")
    console.log("Token Queue items:", data.tokenQueue.length)
    console.log("Departments:", data.departments.length)
    console.log("Emergency Alerts:", data.emergencyAlerts.length)
    console.log("Drug Inventory items:", data.drugInventory.length)

    if (data.tokenQueue.length > 0) {
      console.log("\n🎫 Sample token:", JSON.stringify(data.tokenQueue[0], null, 2))
    }

    if (data.departments.length > 0) {
      console.log("\n🏥 Sample department:", JSON.stringify(data.departments[0], null, 2))
    }

    if (data.emergencyAlerts.length > 0) {
      console.log("\n🚨 Sample alert:", JSON.stringify(data.emergencyAlerts[0], null, 2))
    }

    if (data.drugInventory.length > 0) {
      console.log("\n💊 Sample drug:", JSON.stringify(data.drugInventory[0], null, 2))
    }

    console.log("\n✅ Safe display data test completed!")
  } catch (error) {
    console.error("❌ Error testing safe display data:", error)
  }
}

testSafeDisplayData()
