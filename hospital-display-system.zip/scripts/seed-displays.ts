import { DisplayService } from "@/lib/display-service"

async function seedDisplays() {
  try {
    console.log("Seeding displays...")
    await DisplayService.seedDisplays()
    console.log("✅ Successfully seeded 73 displays")
  } catch (error) {
    console.error("❌ Error seeding displays:", error)
  }
}

// Run the seeding function
seedDisplays()
