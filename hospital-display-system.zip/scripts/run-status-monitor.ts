import { monitorDisplayStatus } from "@/lib/display-status-monitor"

async function runStatusMonitor() {
  try {
    console.log("Starting display status monitor...")

    // Run the monitor once immediately
    await monitorDisplayStatus()

    // Then run it every minute
    setInterval(async () => {
      await monitorDisplayStatus()
    }, 60000)

    console.log("Display status monitor running...")
  } catch (error) {
    console.error("Error in status monitor:", error)
  }
}

runStatusMonitor()
