import { execSync } from "child_process"

console.log("Updating Prisma schema to match database...")

try {
  // Pull the current database schema
  console.log("Running prisma db pull...")
  execSync("npx prisma db pull", { stdio: "inherit" })

  // Generate Prisma client
  console.log("Running prisma generate...")
  execSync("npx prisma generate", { stdio: "inherit" })

  console.log("✅ Prisma schema updated successfully!")
} catch (error) {
  console.error("❌ Error updating Prisma schema:", error)
}
