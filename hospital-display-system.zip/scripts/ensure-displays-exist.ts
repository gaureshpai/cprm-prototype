import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function ensureDisplaysExist() {
  try {
    console.log("Checking if displays exist in database...")

    // Check how many displays we have
    const displayCount = await prisma.display.count()
    console.log(`Found ${displayCount} displays in database`)

    if (displayCount === 0) {
      console.log("No displays found. Creating sample displays...")

      const sampleDisplays = [
        {
          id: "display-001",
          location: "Main Lobby",
          content: "Token Queue",
          status: "offline",
          uptime: "0m",
          lastUpdate: new Date(),
        },
        {
          id: "display-002",
          location: "Emergency Ward",
          content: "Emergency Alerts",
          status: "offline",
          uptime: "0m",
          lastUpdate: new Date(),
        },
        {
          id: "display-003",
          location: "ICU Wing A",
          content: "Department Status",
          status: "offline",
          uptime: "0m",
          lastUpdate: new Date(),
        },
        {
          id: "display-004",
          location: "Pharmacy",
          content: "Drug Inventory",
          status: "offline",
          uptime: "0m",
          lastUpdate: new Date(),
        },
        {
          id: "display-005",
          location: "Cardiology Dept",
          content: "Mixed Dashboard",
          status: "offline",
          uptime: "0m",
          lastUpdate: new Date(),
        },
      ]

      for (const display of sampleDisplays) {
        await prisma.display.create({
          data: display,
        })
        console.log(`Created display: ${display.id} - ${display.location}`)
      }

      console.log(`✅ Created ${sampleDisplays.length} sample displays`)
    } else {
      console.log("✅ Displays already exist in database")

      // Show existing displays
      const displays = await prisma.display.findMany({
        select: {
          id: true,
          location: true,
          status: true,
        },
        take: 10,
      })

      console.log("Existing displays:")
      displays.forEach((display) => {
        console.log(`  - ${display.id}: ${display.location} (${display.status})`)
      })
    }
  } catch (error) {
    console.error("❌ Error ensuring displays exist:", error)
  } finally {
    await prisma.$disconnect()
  }
}

ensureDisplaysExist()
