import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function inspectSchema() {
  try {
    console.log("Inspecting database schema...")

    // Check what tables exist and their structure
    const result = await prisma.$queryRaw`
      SELECT table_name, column_name, data_type, is_nullable
      FROM information_schema.columns 
      WHERE table_schema = 'public' 
      AND table_name IN ('token_queue', 'departments', 'emergency_alerts', 'drug_inventory', 'displays')
      ORDER BY table_name, ordinal_position;
    `

    console.log("Database schema:")
    console.log(JSON.stringify(result, null, 2))
  } catch (error) {
    console.error("❌ Error inspecting schema:", error)
  } finally {
    await prisma.$disconnect()
  }
}

inspectSchema()
