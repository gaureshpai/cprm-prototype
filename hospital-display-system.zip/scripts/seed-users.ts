import { createUserAction, getAllUsersAction } from "@/lib/user-actions"

async function seedUsers() {
  try {
    console.log("Seeding initial users...")

    // Check if users already exist
    const existingUsersResult = await getAllUsersAction()
    if (existingUsersResult.success && existingUsersResult.data && existingUsersResult.data.length > 0) {
      console.log(`Found ${existingUsersResult.data.length} existing users. Skipping seed.`)
      return
    }

    const initialUsers = [
      {
        username: "admin",
        name: "System Administrator",
        email: "admin@hospital.com",
        role: "ADMIN" as const,
        department: "Administration",
      },
      {
        username: "dr.smith",
        name: "Dr. John Smith",
        email: "john.smith@hospital.com",
        role: "DOCTOR" as const,
        department: "Cardiology",
      },
      {
        username: "nurse.jane",
        name: "Jane Wilson",
        email: "jane.wilson@hospital.com",
        role: "NURSE" as const,
        department: "Emergency",
      },
      {
        username: "tech.mike",
        name: "Mike Johnson",
        email: "mike.johnson@hospital.com",
        role: "TECHNICIAN" as const,
        department: "Laboratory",
      },
      {
        username: "pharm.sarah",
        name: "Sarah Davis",
        email: "sarah.davis@hospital.com",
        role: "PHARMACIST" as const,
        department: "Pharmacy",
      },
    ]

    for (const userData of initialUsers) {
      try {
        const formData = new FormData()
        formData.append("username", userData.username)
        formData.append("name", userData.name)
        formData.append("email", userData.email)
        formData.append("role", userData.role)
        formData.append("department", userData.department)

        const result = await createUserAction(formData)
        if (result.success) {
          console.log(`✅ Created user: ${userData.username}`)
        } else {
          console.log(`⚠️ Error creating user ${userData.username}: ${result.error}`)
        }
      } catch (error) {
        console.error(`❌ Error creating user ${userData.username}:`, error)
      }
    }

    console.log("✅ User seeding completed!")
  } catch (error) {
    console.error("❌ Error seeding users:", error)
  }
}

seedUsers()
