import { monitorDisplayStatus } from "@/lib/display-status-monitor"

async function runAggressiveStatusMonitor() {
  try {
    console.log("Starting aggressive display status monitor...")
    console.log("This will check every 30 seconds and mark displays offline after 45 seconds of no heartbeat")

    // Run the monitor once immediately
    await monitorDisplayStatus()

    // Then run it every 30 seconds (more frequent)
    setInterval(async () => {
      await monitorDisplayStatus()
    }, 30000)

    console.log("Aggressive display status monitor running...")
  } catch (error) {
    console.error("Error in aggressive status monitor:", error)
  }
}

runAggressiveStatusMonitor()
