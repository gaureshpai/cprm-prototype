import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function seedSampleData() {
  try {
    console.log("Seeding sample data...")

    // First, let's check what fields are required for tokenQueue
    console.log("Checking existing token queue structure...")

    // Try to get one record to see the structure
    const existingToken = await prisma.tokenQueue.findFirst()
    if (existingToken) {
      console.log("Existing token structure:", existingToken)
    }

    // Seed token queue data with all required fields
    await prisma.tokenQueue.createMany({
      data: [
        {
          tokenId: "T001",
          patientName: "John Doe",
          status: "waiting",
          department: "Cardiology", // Added missing department field
          priority: 1,
          estimatedTime: "15 min",
        },
        {
          tokenId: "T002",
          patientName: "Jane Smith",
          status: "in_progress",
          department: "Emergency", // Added missing department field
          priority: 3,
          estimatedTime: "5 min",
        },
        {
          tokenId: "T003",
          patientName: "Bob Johnson",
          status: "waiting",
          department: "Neurology", // Added missing department field
          priority: 2,
          estimatedTime: "25 min",
        },
      ],
      skipDuplicates: true,
    })

    // Seed departments data
    await prisma.department.createMany({
      data: [
        {
          departmentName: "Cardiology",
          location: "Ground Floor",
          status: "active",
          currentTokens: 5,
          avgWaitTime: 20,
        },
        {
          departmentName: "Emergency",
          location: "First Floor",
          status: "active",
          currentTokens: 12,
          avgWaitTime: 10,
        },
        {
          departmentName: "Neurology",
          location: "Second Floor",
          status: "active",
          currentTokens: 3,
          avgWaitTime: 30,
        },
      ],
      skipDuplicates: true,
    })

    // Seed emergency alerts data
    await prisma.emergencyAlert.createMany({
      data: [
        {
          codeType: "Code Blue",
          location: "Emergency Ward",
          message: "Medical emergency in progress",
          status: "active",
          broadcastTo: ["Emergency", "ICU"],
          priority: 5,
        },
      ],
      skipDuplicates: true,
    })

    // Seed drug inventory data
    await prisma.drugInventory.createMany({
      data: [
        {
          drugName: "Paracetamol",
          currentStock: 5,
          minStock: 50,
          status: "critical",
          location: "Main Pharmacy",
          category: "Pain Relief",
          expiryDate: new Date("2025-12-31"),
          batchNumber: "PAR001",
        },
        {
          drugName: "Insulin",
          currentStock: 2,
          minStock: 20,
          status: "critical",
          location: "Main Pharmacy",
          category: "Diabetes",
          expiryDate: new Date("2025-08-15"),
          batchNumber: "INS001",
        },
      ],
      skipDuplicates: true,
    })

    console.log("✅ Sample data seeded successfully!")
  } catch (error) {
    console.error("❌ Error seeding sample data:", error)
    console.error("Full error details:", error)
  } finally {
    await prisma.$disconnect()
  }
}

seedSampleData()
