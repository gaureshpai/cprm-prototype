import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function seedDisplaysOnly() {
  try {
    console.log("Seeding displays only...")

    // Check if displays already exist
    const existingDisplays = await prisma.display.count()
    if (existingDisplays > 0) {
      console.log(`Found ${existingDisplays} existing displays. Skipping seed.`)
      return
    }

    const locations = [
      "Main Lobby",
      "Emergency Ward",
      "ICU Wing A",
      "ICU Wing B",
      "OT Complex 1",
      "OT Complex 2",
      "Cardiology Dept",
      "Neurology Dept",
      "Pediatrics Ward",
      "Maternity Ward",
      "Pharmacy Main",
      "Pharmacy Emergency",
      "Blood Bank",
      "Laboratory",
      "Radiology",
      "Cafeteria",
      "Admin Office",
      "Reception Desk",
      "Waiting Area A",
      "Waiting Area B",
    ]

    const contentTypes = ["Token Queue", "Department Status", "Emergency Alerts", "Drug Inventory", "Mixed Dashboard"]

    const displaysToCreate = locations.map((location, index) => ({
      location,
      content: contentTypes[index % contentTypes.length],
      status: Math.random() > 0.3 ? "online" : Math.random() > 0.5 ? "offline" : "warning",
      uptime: `${Math.floor(Math.random() * 24)}h ${Math.floor(Math.random() * 60)}m`,
      lastUpdate: new Date(Date.now() - Math.random() * 3600000),
    }))

    await prisma.display.createMany({
      data: displaysToCreate,
    })

    console.log(`✅ Successfully seeded ${displaysToCreate.length} displays!`)
  } catch (error) {
    console.error("❌ Error seeding displays:", error)
  } finally {
    await prisma.$disconnect()
  }
}

seedDisplaysOnly()
