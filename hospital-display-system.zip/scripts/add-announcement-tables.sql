-- Add announcements table
CREATE TABLE IF NOT EXISTS announcements (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    text TEXT NOT NULL,
    created_by TEXT NOT NULL,
    active BOOLEAN DEFAULT true,
    priority INTEGER DEFAULT 1,
    target_displays TEXT[] DEFAULT '{}',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Add content_items table
CREATE TABLE IF NOT EXISTS content_items (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    title TEXT NOT NULL,
    type TEXT NOT NULL,
    content TEXT NOT NULL,
    active BOOLEAN DEFAULT true,
    target_displays TEXT[] DEFAULT '{}',
    schedule_start TIMESTAMP,
    schedule_end TIMESTAMP,
    created_by TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_announcements_active ON announcements(active);
CREATE INDEX IF NOT EXISTS idx_announcements_created_at ON announcements(created_at);
CREATE INDEX IF NOT EXISTS idx_content_items_active ON content_items(active);
CREATE INDEX IF NOT EXISTS idx_content_items_type ON content_items(type);

-- Insert a default admin user if none exists
INSERT INTO users (id, username, email, name, role, status)
SELECT 'admin-default', 'admin', 'admin@hospital.com', 'System Administrator', 'ADMIN', 'ACTIVE'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE role = 'ADMIN');

-- Insert sample announcements
INSERT INTO announcements (text, created_by, priority, active)
SELECT 'Hospital visiting hours have been updated to 4:00 PM - 7:00 PM daily', 
       (SELECT id FROM users WHERE role = 'ADMIN' LIMIT 1), 
       2, 
       true
WHERE NOT EXISTS (SELECT 1 FROM announcements);

INSERT INTO announcements (text, created_by, priority, active)
SELECT 'New COVID-19 vaccination drive starting next week. Contact reception for appointments.', 
       (SELECT id FROM users WHERE role = 'ADMIN' LIMIT 1), 
       1, 
       true
WHERE NOT EXISTS (SELECT 1 FROM announcements WHERE text LIKE '%COVID-19%');

-- Insert sample content items
INSERT INTO content_items (title, type, content, created_by, active)
SELECT 'Health Education: Hand Hygiene', 
       'Educational', 
       'Proper hand hygiene prevents infections. Wash hands for 20 seconds with soap and water.', 
       (SELECT id FROM users WHERE role = 'ADMIN' LIMIT 1), 
       true
WHERE NOT EXISTS (SELECT 1 FROM content_items);

INSERT INTO content_items (title, type, content, created_by, active)
SELECT 'Visiting Hours Information', 
       'Information', 
       'General visiting hours: 4:00 PM - 7:00 PM daily. ICU visiting hours: 2:00 PM - 4:00 PM.', 
       (SELECT id FROM users WHERE role = 'ADMIN' LIMIT 1), 
       true
WHERE NOT EXISTS (SELECT 1 FROM content_items WHERE title LIKE '%Visiting Hours%');

COMMIT;
