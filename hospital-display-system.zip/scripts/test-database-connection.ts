import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function testDatabaseConnection() {
  try {
    console.log("Testing database connection...")
    console.log("Database URL:", process.env.DATABASE_URL ? "Set" : "Not set")

    // Test basic connection
    await prisma.$connect()
    console.log("✅ Database connection successful!")

    // Test a simple query
    const result = await prisma.$queryRaw`SELECT 1 as test`
    console.log("✅ Database query successful:", result)

    // Check if users table exists
    try {
      const userCount = await prisma.user.count()
      console.log(`✅ Users table exists with ${userCount} records`)
    } catch (error) {
      console.log("⚠️ Users table may not exist:", error.message)
    }
  } catch (error) {
    console.error("❌ Database connection failed:")
    console.error("Error code:", error.code)
    console.error("Error message:", error.message)

    if (error.message.includes("Can't reach database server")) {
      console.log("\n🔧 Troubleshooting steps:")
      console.log("1. Check if your Neon database is active (it may be paused)")
      console.log("2. Verify your DATABASE_URL environment variable")
      console.log("3. Check your internet connection")
      console.log("4. Try restarting your Neon database from the dashboard")
    }
  } finally {
    await prisma.$disconnect()
  }
}

testDatabaseConnection()
