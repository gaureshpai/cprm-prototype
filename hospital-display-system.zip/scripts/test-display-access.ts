import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

async function testDisplayAccess() {
  try {
    console.log("Testing display access...")

    // Get the first display
    const firstDisplay = await prisma.display.findFirst()

    if (!firstDisplay) {
      console.log("❌ No displays found in database")
      return
    }

    console.log("✅ Found display:", {
      id: firstDisplay.id,
      location: firstDisplay.location,
      status: firstDisplay.status,
      content: firstDisplay.content,
    })

    console.log(`\n🔗 You can access this display at:`)
    console.log(`   http://localhost:3000/display/${firstDisplay.id}`)

    // Test the heartbeat endpoint
    console.log("\n🔄 Testing heartbeat functionality...")

    try {
      const response = await fetch("http://localhost:3000/api/displays/heartbeat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ displayId: firstDisplay.id }),
      })

      if (response.ok) {
        console.log("✅ Heartbeat endpoint is working")

        // Check if status was updated
        const updatedDisplay = await prisma.display.findUnique({
          where: { id: firstDisplay.id },
        })

        console.log(`   Status updated to: ${updatedDisplay?.status}`)
      } else {
        console.log("❌ Heartbeat endpoint failed:", response.status)
      }
    } catch (fetchError) {
      console.log("⚠️ Could not test heartbeat (server may not be running):", fetchError.message)
    }
  } catch (error) {
    console.error("❌ Error testing display access:", error)
  } finally {
    await prisma.$disconnect()
  }
}

testDisplayAccess()
