"use client"

import { useState, useEffect, useTransition, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Users, Activity, AlertTriangle, Heart, Pill } from "lucide-react"
import { getDisplayDataAction } from "@/lib/display-actions"

interface PublicDisplayProps {
    displayId: string
    displayData?: {
        id: string
        location: string
        status: string
        content: string
        uptime: string
        lastUpdate: string
        isActive: boolean
        config?: any
    }
}

interface DisplayData {
    tokenQueue: Array<{
        token_id: string
        patient_name: string
        display_name?: string | null
        status: string
        department: string
        priority: number
        estimated_time?: string | null
    }>
    departments: Array<{
        dept_id: string
        department_name: string
        location: string
        current_tokens: number
    }>
    emergencyAlerts: Array<{
        id: string
        codeType: string
        location: string
        message: string
        priority: number
    }>
    drugInventory: Array<{
        drug_id: string
        drug_name: string
        current_stock: number
        min_stock: number
        status: string
    }>
    contentType?: string
}

export default function PublicDisplayPage({ displayId, displayData }: PublicDisplayProps) {
    const [data, setData] = useState<DisplayData>({
        tokenQueue: [],
        departments: [],
        emergencyAlerts: [],
        drugInventory: [],
        contentType: "Mixed Dashboard",
    })
    const [currentTime, setCurrentTime] = useState<Date | null>(null)
    const [emergencyAlert, setEmergencyAlert] = useState<any>(null)
    const [isLoading, setIsLoading] = useState(true)
    const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
    const [isPending, startTransition] = useTransition()
    const [heartbeatError, setHeartbeatError] = useState<string | null>(null)
    const [isVisible, setIsVisible] = useState(true)
    const [currentSlide, setCurrentSlide] = useState(0)

    const heartbeatIntervalRef = useRef<NodeJS.Timeout | null>(null)
    const dataIntervalRef = useRef<NodeJS.Timeout | null>(null)
    const timeIntervalRef = useRef<NodeJS.Timeout | null>(null)
    const slideIntervalRef = useRef<NodeJS.Timeout | null>(null)

    const sendHeartbeat = async (status: "online" | "offline" = "online") => {
        try {
            const response = await fetch("/api/displays/heartbeat", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    displayId,
                    status,
                    timestamp: new Date().toISOString(),
                }),
            })

            if (!response.ok) {
                const data = await response.json()
                setHeartbeatError(`Heartbeat failed: ${data.error || response.statusText}`)
            } else {
                setHeartbeatError(null)
                console.log(`Heartbeat sent: ${status}`)
            }
        } catch (error) {
            console.error("Error sending heartbeat:", error)
            setHeartbeatError(`Connection error: ${error}`)
        }
    }

    const sendOfflineSignal = async () => {
        try {
            await sendHeartbeat("offline")
            console.log("Offline signal sent")
        } catch (error) {
            console.error("Error sending offline signal:", error)
        }
    }

    useEffect(() => {
        const handleVisibilityChange = () => {
            const visible = !document.hidden
            setIsVisible(visible)

            if (visible) {
                console.log("Page became visible - sending online heartbeat")
                sendHeartbeat("online")

                if (!heartbeatIntervalRef.current) {
                    heartbeatIntervalRef.current = setInterval(() => sendHeartbeat("online"), 15000)
                }
                if (!dataIntervalRef.current) {
                    dataIntervalRef.current = setInterval(() => fetchDisplayData(false), 5000)
                }
            } else {
                console.log("Page became hidden - sending offline signal")
                sendOfflineSignal()

                if (heartbeatIntervalRef.current) {
                    clearInterval(heartbeatIntervalRef.current)
                    heartbeatIntervalRef.current = null
                }
                if (dataIntervalRef.current) {
                    clearInterval(dataIntervalRef.current)
                    dataIntervalRef.current = null
                }
            }
        }

        document.addEventListener("visibilitychange", handleVisibilityChange)

        return () => {
            document.removeEventListener("visibilitychange", handleVisibilityChange)
        }
    }, [displayId])

    useEffect(() => {
        const handleBeforeUnload = () => {
            console.log("Page unloading - sending offline signal")

            navigator.sendBeacon(
                "/api/displays/heartbeat",
                JSON.stringify({
                    displayId,
                    status: "offline",
                    timestamp: new Date().toISOString(),
                }),
            )
        }

        const handleUnload = () => {
            sendOfflineSignal()
        }

        window.addEventListener("beforeunload", handleBeforeUnload)
        window.addEventListener("unload", handleUnload)

        return () => {
            window.removeEventListener("beforeunload", handleBeforeUnload)
            window.removeEventListener("unload", handleUnload)

            sendOfflineSignal()
        }
    }, [displayId])

    useEffect(() => {
        sendHeartbeat("online")

        heartbeatIntervalRef.current = setInterval(() => {
            if (!document.hidden) {
                sendHeartbeat("online")
            }
        }, 15000)

        return () => {
            if (heartbeatIntervalRef.current) {
                clearInterval(heartbeatIntervalRef.current)
            }

            sendOfflineSignal()
        }
    }, [displayId])

    const fetchDisplayData = async (showLoading = true) => {
        try {
            if (showLoading) setIsLoading(true)

            startTransition(async () => {
                const displayData = await getDisplayDataAction(displayId)
                setData(displayData)
                setLastUpdate(new Date())
                
                const activeEmergencyAlert = displayData.emergencyAlerts.find((alert) => alert.priority >= 4)

                if (activeEmergencyAlert) {                    
                    if (!emergencyAlert || emergencyAlert.id !== activeEmergencyAlert.id) {
                        setEmergencyAlert(activeEmergencyAlert)
                        setTimeout(() => setEmergencyAlert(null), 2 * 60 * 1000)
                    }
                } else {
                    if (emergencyAlert) {
                        setEmergencyAlert(null)
                    }
                }
            })
        } catch (error) {
            console.error("Error fetching display data:", error)
        } finally {
            if (showLoading) setIsLoading(false)
        }
    }

    useEffect(() => {
        fetchDisplayData()

        dataIntervalRef.current = setInterval(() => {
            if (!document.hidden) {
                fetchDisplayData(false)
            }
        }, 5000)

        timeIntervalRef.current = setInterval(() => setCurrentTime(new Date()), 1000)

        return () => {
            if (dataIntervalRef.current) {
                clearInterval(dataIntervalRef.current)
            }
            if (timeIntervalRef.current) {
                clearInterval(timeIntervalRef.current)
            }
        }
    }, [displayId])
    
    useEffect(() => {
        const contentType = data.contentType || displayData?.content || "Mixed Dashboard"
        if (contentType === "Mixed Dashboard") {
            slideIntervalRef.current = setInterval(() => {
                setCurrentSlide(prev => (prev + 1) % 4) 
            }, 10000) 

            return () => {
                if (slideIntervalRef.current) {
                    clearInterval(slideIntervalRef.current)
                }
            }
        }
    }, [data.contentType, displayData?.content])

    const contentType = data.contentType || displayData?.content || "Mixed Dashboard"
    
    if (emergencyAlert) {
        return (
            <div className="fixed inset-0 bg-red-600 bg-opacity-95 z-50 flex items-center justify-center w-screen h-screen">
                <div className="text-center text-white">
                    <AlertTriangle className="h-32 w-32 mx-auto mb-8 animate-pulse" />
                    <h1 className="text-8xl font-bold mb-8">{emergencyAlert.codeType}</h1>
                    <p className="text-4xl mb-4">{emergencyAlert.location}</p>
                    <p className="text-3xl mb-8">{emergencyAlert.message}</p>
                    <div className="mt-12 text-2xl space-y-4">
                        <p>Please follow emergency procedures</p>
                        <p>Staff report to designated areas immediately</p>
                    </div>
                </div>
            </div>
        )
    }

    const renderSlideContent = () => {
        if (contentType !== "Mixed Dashboard") {
            
            if (contentType === "Token Queue" && data.tokenQueue.length > 0) {
                return renderTokenQueue(true)
            } else if (contentType === "Department Status" && data.departments.length > 0) {
                return renderDepartments(true)
            } else if (contentType === "Drug Inventory" && data.drugInventory.length > 0) {
                return renderDrugInventory(true)
            } else if (contentType === "Emergency Alerts" && data.emergencyAlerts.length > 0) {
                return renderEmergencyAlerts(true)
            } else {
                return renderNoDataMessage()
            }
        } else {
            
            switch (currentSlide) {
                case 0:
                    return data.tokenQueue.length > 0 ? renderTokenQueue(true) : renderHospitalInfo(true)
                case 1:
                    return data.departments.length > 0 ? renderDepartments(true) : renderHospitalInfo(true)
                case 2:
                    return data.drugInventory.length > 0 ? renderDrugInventory(true) : renderHospitalInfo(true)
                case 3:
                default:
                    return renderHospitalInfo(true)
            }
        }
    }

    const renderTokenQueue = (fullScreen = false) => (
        <Card className={`shadow-lg ${fullScreen ? 'h-full' : ''}`}>
            <CardHeader className="bg-blue-600 text-white">
                <CardTitle className="flex items-center space-x-2 text-4xl">
                    <Users className="h-10 w-10" />
                    <span>Current Queue</span>
                </CardTitle>
            </CardHeader>
            <CardContent className={`${fullScreen ? 'flex-1 flex flex-col justify-center' : ''} p-8`}>
                <div className="space-y-6">
                    {data.tokenQueue.slice(0, fullScreen ? 8 : 4).map((token, index) => (
                        <div
                            key={token.token_id}
                            className={`flex justify-between items-center p-6 rounded-lg ${index === 0 ? "bg-green-100 border-4 border-green-500" : "bg-gray-50"
                                }`}
                        >
                            <div>
                                <div className="text-4xl font-bold">Token #{token.token_id}</div>
                                <div className="text-2xl text-gray-600">{token.display_name || token.patient_name}</div>
                                <div className="text-xl text-gray-500">{token.department}</div>
                            </div>
                            <div className="text-right">
                                <Badge
                                    className={`text-2xl px-4 py-2 ${token.status === "in_progress"
                                            ? "bg-blue-500"
                                            : token.status === "waiting"
                                                ? "bg-yellow-500"
                                                : "bg-gray-500"
                                        }`}
                                >
                                    {token.status === "in_progress" ? "In Progress" : "Waiting"}
                                </Badge>
                                {token.estimated_time && (
                                    <div className="text-lg text-gray-500 mt-2">ETA: {token.estimated_time}</div>
                                )}
                                {index === 0 && <div className="text-green-600 font-bold text-xl mt-2">NOW SERVING</div>}
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    )

    const renderDepartments = (fullScreen = false) => (
        <Card className={`shadow-lg ${fullScreen ? 'h-full' : ''}`}>
            <CardHeader className="bg-green-600 text-white">
                <CardTitle className="flex items-center space-x-2 text-4xl">
                    <Activity className="h-10 w-10" />
                    <span>Department Status</span>
                </CardTitle>
            </CardHeader>
            <CardContent className={`${fullScreen ? 'flex-1 flex flex-col justify-center' : ''} p-8`}>
                <div className="space-y-6">
                    {data.departments.map((dept) => (
                        <div key={dept.dept_id} className="flex justify-between items-center p-6 bg-gray-50 rounded-lg">
                            <div>
                                <div className="text-3xl font-semibold">{dept.department_name}</div>
                                <div className="text-xl text-gray-600">{dept.location}</div>
                            </div>
                            <div className="text-right">
                                <div className="text-5xl font-bold text-blue-600">{dept.current_tokens}</div>
                                <div className="text-lg text-gray-500">patients waiting</div>
                            </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    )

    const renderDrugInventory = (fullScreen = false) => (
        <Card className={`shadow-lg ${fullScreen ? 'h-full' : ''}`}>
            <CardHeader className="bg-red-600 text-white">
                <CardTitle className="flex items-center space-x-2 text-4xl">
                    <Pill className="h-10 w-10" />
                    <span>Critical Stock Alerts</span>
                </CardTitle>
            </CardHeader>
            <CardContent className={`${fullScreen ? 'flex-1 flex flex-col justify-center' : ''} p-8`}>
                <div className="grid grid-cols-1 gap-6">
                    {data.drugInventory.map((drug) => (
                        <Alert key={drug.drug_id} className="border-red-200 bg-red-50 p-6">
                            <AlertTriangle className="h-8 w-8 text-red-600" />
                            <AlertDescription className="text-red-800 text-2xl">
                                <strong className="text-3xl">{drug.drug_name}</strong> - Critical stock level
                                <br />
                                <span className="text-xl">
                                    Current: {drug.current_stock} | Min: {drug.min_stock}
                                </span>
                                <br />
                                <span className="text-xl">Contact pharmacy immediately</span>
                            </AlertDescription>
                        </Alert>
                    ))}
                </div>
            </CardContent>
        </Card>
    )

    const renderEmergencyAlerts = (fullScreen = false) => (
        <Card className={`shadow-lg ${fullScreen ? 'h-full' : ''}`}>
            <CardHeader className="bg-orange-600 text-white">
                <CardTitle className="flex items-center space-x-2 text-4xl">
                    <AlertTriangle className="h-10 w-10" />
                    <span>Active Emergency Alerts</span>
                </CardTitle>
            </CardHeader>
            <CardContent className={`${fullScreen ? 'flex-1 flex flex-col justify-center' : ''} p-8`}>
                <div className="space-y-6">
                    {data.emergencyAlerts.map((alert) => (
                        <Alert key={alert.id} className="border-orange-200 bg-orange-50 p-6">
                            <AlertTriangle className="h-8 w-8 text-orange-600" />
                            <AlertDescription className="text-orange-800 text-2xl">
                                <strong className="text-3xl">{alert.codeType}</strong> - {alert.location}
                                <br />
                                <span className="text-xl">{alert.message}</span>
                            </AlertDescription>
                        </Alert>
                    ))}
                </div>
            </CardContent>
        </Card>
    )

    const renderHospitalInfo = (fullScreen = false) => (
        <Card className={`shadow-lg ${fullScreen ? 'h-full' : ''}`}>
            <CardHeader className="bg-gray-600 text-white">
                <CardTitle className="flex items-center space-x-2 text-4xl">
                    <Heart className="h-10 w-10" />
                    <span>Hospital Information</span>
                </CardTitle>
            </CardHeader>
            <CardContent className={`${fullScreen ? 'flex-1 flex flex-col justify-center' : ''} p-8`}>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                    <div>
                        <h3 className="text-3xl font-semibold mb-4">Emergency</h3>
                        <p className="text-6xl font-bold text-red-600">108</p>
                        <p className="text-2xl text-gray-600">24/7 Emergency Services</p>
                    </div>
                    <div>
                        <h3 className="text-3xl font-semibold mb-4">General Inquiry</h3>
                        <p className="text-4xl font-bold text-blue-600">0824-2444444</p>
                        <p className="text-2xl text-gray-600">Reception & Information</p>
                    </div>
                    <div>
                        <h3 className="text-3xl font-semibold mb-4">Visiting Hours</h3>
                        <p className="text-4xl font-bold text-green-600">4:00 PM - 7:00 PM</p>
                        <p className="text-2xl text-gray-600">Daily visiting hours</p>
                    </div>
                </div>
            </CardContent>
        </Card>
    )

    const renderNoDataMessage = () => (
        <Card className="shadow-lg h-full">
            <CardContent className="p-8 text-center flex flex-col justify-center h-full">
                <div className="text-gray-500">
                    <h3 className="text-4xl font-semibold mb-4">No {contentType} Data Available</h3>
                    <p className="text-2xl">This display is configured to show {contentType} but no data is currently available.</p>
                    <p className="text-xl mt-4">Data will appear here when available.</p>
                </div>
            </CardContent>
        </Card>
    )

    return (
        <div className="fixed inset-0 w-screen h-screen bg-gradient-to-br from-blue-50 to-white overflow-hidden">
            {/* Status Bar */}
            <div className="absolute top-0 left-0 right-0 z-10 bg-white bg-opacity-90 backdrop-blur-sm p-4">
                <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-4">
                        <h1 className="text-3xl font-bold text-gray-900">Wenlock Hospital</h1>
                        {contentType === "Mixed Dashboard" && (
                            <div className="flex items-center space-x-2">
                                <span className="text-sm text-gray-500">Slide {currentSlide + 1}/4</span>
                                <div className="flex space-x-1">
                                    {[0, 1, 2, 3].map((index) => (
                                        <div
                                            key={index}
                                            className={`w-2 h-2 rounded-full ${index === currentSlide ? "bg-blue-500" : "bg-gray-300"
                                                }`}
                                        />
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                    <div className="text-right">
                        <div className="text-2xl font-bold text-blue-600">{currentTime?.toLocaleTimeString("en-US")}</div>
                        <div className="text-lg text-gray-600">{currentTime?.toLocaleDateString("en-US")}</div>
                    </div>
                </div>

                {heartbeatError && (
                    <Alert className="mt-2 border-red-200 bg-red-50">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                        <AlertDescription className="text-red-800">{heartbeatError}</AlertDescription>
                    </Alert>
                )}
            </div>

            {/* Main Content Area */}
            <div className="pt-20 pb-16 px-8 h-full">
                <div className="h-full flex flex-col">
                    {renderSlideContent()}
                </div>
            </div>

            {/* Footer */}
            <div className="absolute bottom-0 left-0 right-0 bg-white bg-opacity-90 backdrop-blur-sm p-4 text-center text-gray-500">
                <p className="text-lg">© 2025 Wenlock Hospital • UDAL Fellowship Challenge</p>
                <div className="flex justify-center space-x-8 text-sm mt-2">
                    <span>Real-time updates every 5 seconds</span>
                    <span>Patient privacy protected</span>
                    <span>Last Update: {lastUpdate?.toLocaleTimeString("en-US")}</span>
                    {isPending && <span className="text-blue-600">• Updating...</span>}
                </div>
            </div>
        </div>
    )
}
