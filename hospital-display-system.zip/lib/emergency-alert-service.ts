"use server"

import { PrismaClient } from "@prisma/client"
import { revalidatePath } from "next/cache"

const prisma = new PrismaClient()

export interface EmergencyAlertData {
  id: string
  codeType: string
  location: string
  message: string
  priority: number
  status: string
  severity: string
  department: string
  affectedAreas: string[]
  responseTeam: string[]
  createdAt: Date
  resolvedAt?: Date | null
  autoResolveMinutes?: number
}

export interface CreateEmergencyAlertData {
  codeType: string
  location: string
  message?: string
  priority: number
  severity: string
  department: string
  affectedAreas?: string[]
  responseTeam?: string[]
  autoResolveMinutes?: number
}

export async function createEmergencyAlert(data: CreateEmergencyAlertData): Promise<EmergencyAlertData> {
  try {
    const alert = await prisma.emergencyAlert.create({
      data: {
        codeType: data.codeType,
        location: data.location,
        message: data.message || `${data.codeType} at ${data.location}`,
        priority: data.priority,
        status: "active",
        severity: data.severity,
        department: data.department,
        affectedAreas: data.affectedAreas || [],
        responseTeam: data.responseTeam || [],
        autoResolveMinutes: data.autoResolveMinutes,
      },
    })

    // Auto-resolve after specified time if set
    if (data.autoResolveMinutes) {
      setTimeout(
        async () => {
          await resolveEmergencyAlert(alert.id)
        },
        data.autoResolveMinutes * 60 * 1000,
      )
    }

    // Trigger real-time updates
    revalidatePath("/display")
    revalidatePath("/admin")

    return {
      id: alert.id,
      codeType: alert.codeType,
      location: alert.location,
      message: alert.message,
      priority: alert.priority,
      status: alert.status,
      severity: data.severity,
      department: data.department,
      affectedAreas: data.affectedAreas || [],
      responseTeam: data.responseTeam || [],
      createdAt: alert.createdAt,
      resolvedAt: alert.resolvedAt,
      autoResolveMinutes: data.autoResolveMinutes,
    }
  } catch (error) {
    console.error("Error creating emergency alert:", error)
    throw new Error("Failed to create emergency alert")
  }
}

export async function resolveEmergencyAlert(alertId: string): Promise<boolean> {
  try {
    await prisma.emergencyAlert.update({
      where: { id: alertId },
      data: {
        status: "resolved",
        resolvedAt: new Date(),
      },
    })

    // Trigger real-time updates
    revalidatePath("/display")
    revalidatePath("/admin")

    return true
  } catch (error) {
    console.error("Error resolving emergency alert:", error)
    throw new Error("Failed to resolve emergency alert")
  }
}

export async function getActiveEmergencyAlerts(): Promise<EmergencyAlertData[]> {
  try {
    const alerts = await prisma.emergencyAlert.findMany({
      where: { status: "active" },
      orderBy: [{ priority: "desc" }, { createdAt: "desc" }],
    })

    return alerts.map((alert) => ({
      id: alert.id,
      codeType: alert.codeType,
      location: alert.location,
      message: alert.message,
      priority: alert.priority,
      status: alert.status,
      severity: alert.severity || "medium",
      department: alert.department || "Unknown",
      affectedAreas: alert.affectedAreas || [],
      responseTeam: alert.responseTeam || [],
      createdAt: alert.createdAt,
      resolvedAt: alert.resolvedAt,
      autoResolveMinutes: alert.autoResolveMinutes,
    }))
  } catch (error) {
    console.error("Error fetching active emergency alerts:", error)
    return []
  }
}

export async function getAllEmergencyAlerts(limit = 50): Promise<EmergencyAlertData[]> {
  try {
    const alerts = await prisma.emergencyAlert.findMany({
      orderBy: [{ createdAt: "desc" }],
      take: limit,
    })

    return alerts.map((alert) => ({
      id: alert.id,
      codeType: alert.codeType,
      location: alert.location,
      message: alert.message,
      priority: alert.priority,
      status: alert.status,
      severity: alert.severity || "medium",
      department: alert.department || "Unknown",
      affectedAreas: alert.affectedAreas || [],
      responseTeam: alert.responseTeam || [],
      createdAt: alert.createdAt,
      resolvedAt: alert.resolvedAt,
      autoResolveMinutes: alert.autoResolveMinutes,
    }))
  } catch (error) {
    console.error("Error fetching emergency alerts:", error)
    return []
  }
}

// Predefined emergency codes with their configurations
export const EMERGENCY_CODES = {
  "Code Blue": {
    priority: 5,
    severity: "critical",
    autoResolveMinutes: 30,
    responseTeam: ["Emergency Team", "ICU Staff", "Cardiology"],
    description: "Medical emergency - cardiac or respiratory arrest",
  },
  "Code Red": {
    priority: 5,
    severity: "critical",
    autoResolveMinutes: 60,
    responseTeam: ["Fire Safety", "Security", "Evacuation Team"],
    description: "Fire emergency",
  },
  "Code Black": {
    priority: 5,
    severity: "critical",
    autoResolveMinutes: null,
    responseTeam: ["Security", "Police", "Administration"],
    description: "Bomb threat or security threat",
  },
  "Code Orange": {
    priority: 4,
    severity: "high",
    autoResolveMinutes: 120,
    responseTeam: ["Emergency Management", "Administration"],
    description: "External disaster or mass casualty",
  },
  "Code Silver": {
    priority: 5,
    severity: "critical",
    autoResolveMinutes: null,
    responseTeam: ["Security", "Police", "Lockdown Team"],
    description: "Weapon or hostage situation",
  },
  "Code Yellow": {
    priority: 3,
    severity: "medium",
    autoResolveMinutes: 60,
    responseTeam: ["Security", "Nursing Staff"],
    description: "Missing patient",
  },
  "Code Pink": {
    priority: 4,
    severity: "high",
    autoResolveMinutes: 30,
    responseTeam: ["Security", "Pediatric Staff", "Administration"],
    description: "Infant or child abduction",
  },
  "Code Green": {
    priority: 2,
    severity: "low",
    autoResolveMinutes: 15,
    responseTeam: ["Maintenance", "Engineering"],
    description: "Emergency activation",
  },
}

export async function createCodeBlueAlert(location: string, details?: string): Promise<EmergencyAlertData> {
  const codeConfig = EMERGENCY_CODES["Code Blue"]

  return createEmergencyAlert({
    codeType: "Code Blue",
    location,
    message: details || `Code Blue - Medical emergency at ${location}. Immediate response required.`,
    priority: codeConfig.priority,
    severity: codeConfig.severity,
    department: "Emergency",
    affectedAreas: [location, "Emergency Department", "ICU"],
    responseTeam: codeConfig.responseTeam,
    autoResolveMinutes: codeConfig.autoResolveMinutes || undefined,
  })
}
