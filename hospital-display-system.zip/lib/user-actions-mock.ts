"use server"

import type { Role } from "@prisma/client"

export interface CreateUserData {
  username: string
  name: string
  email?: string
  role: Role
  department?: string
}

export interface UpdateUserData {
  name?: string
  email?: string
  department?: string
  role?: Role
  status?: string
}

export interface UserWithStats {
  id: string
  username: string
  name: string
  email?: string | null
  role: Role
  department?: string | null
  status: string
  createdAt: Date
  updatedAt: Date
  permissions: any
}

export interface UserActionResponse<T> {
  success: boolean
  data?: T
  error?: string
}

// Mock data store (in a real app, this would be in a database)
const mockUsers: UserWithStats[] = [
  {
    id: "user-1",
    username: "admin",
    name: "System Administrator",
    email: "admin@hospital.com",
    role: "ADMIN",
    department: "Administration",
    status: "ACTIVE",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
    permissions: [
      "user_management",
      "display_management",
      "content_management",
      "emergency_alerts",
      "system_settings",
      "analytics",
    ],
  },
  {
    id: "user-2",
    username: "dr.smith",
    name: "Dr. John Smith",
    email: "john.smith@hospital.com",
    role: "DOCTOR",
    department: "Cardiology",
    status: "ACTIVE",
    createdAt: new Date("2024-01-02"),
    updatedAt: new Date("2024-01-02"),
    permissions: ["patient_management", "appointments", "prescriptions", "medical_records"],
  },
  {
    id: "user-3",
    username: "nurse.jane",
    name: "Jane Wilson",
    email: "jane.wilson@hospital.com",
    role: "NURSE",
    department: "Emergency",
    status: "ACTIVE",
    createdAt: new Date("2024-01-03"),
    updatedAt: new Date("2024-01-03"),
    permissions: ["patient_care", "appointments", "medication_administration"],
  },
  {
    id: "user-4",
    username: "tech.mike",
    name: "Mike Johnson",
    email: "mike.johnson@hospital.com",
    role: "TECHNICIAN",
    department: "Laboratory",
    status: "ACTIVE",
    createdAt: new Date("2024-01-04"),
    updatedAt: new Date("2024-01-04"),
    permissions: ["equipment_management", "maintenance", "technical_support"],
  },
  {
    id: "user-5",
    username: "pharm.sarah",
    name: "Sarah Davis",
    email: "sarah.davis@hospital.com",
    role: "PHARMACIST",
    department: "Pharmacy",
    status: "ACTIVE",
    createdAt: new Date("2024-01-05"),
    updatedAt: new Date("2024-01-05"),
    permissions: ["drug_inventory", "prescriptions", "medication_dispensing"],
  },
]

// Get all users
export async function getAllUsersAction(): Promise<UserActionResponse<UserWithStats[]>> {
  try {
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    return { success: true, data: [...mockUsers] }
  } catch (error) {
    console.error("Error finding all users:", error)
    return { success: false, error: "Failed to fetch users" }
  }
}

// Get user by ID
export async function getUserByIdAction(id: string): Promise<UserActionResponse<UserWithStats>> {
  try {
    await new Promise((resolve) => setTimeout(resolve, 200))

    const user = mockUsers.find((u) => u.id === id)

    if (!user) {
      return { success: false, error: "User not found" }
    }

    return { success: true, data: user }
  } catch (error) {
    console.error("Error finding user by ID:", error)
    return { success: false, error: "Failed to fetch user" }
  }
}

// Create new user
export async function createUserAction(formData: FormData): Promise<UserActionResponse<UserWithStats>> {
  try {
    const username = formData.get("username") as string
    const name = formData.get("name") as string
    const email = formData.get("email") as string
    const role = formData.get("role") as Role
    const department = formData.get("department") as string

    if (!username || !name || !role) {
      return { success: false, error: "Username, name, and role are required" }
    }

    // Check if username already exists
    const existingUser = mockUsers.find((u) => u.username === username)
    if (existingUser) {
      return { success: false, error: "Username already exists" }
    }

    // Check if email already exists (if provided)
    if (email) {
      const existingEmail = mockUsers.find((u) => u.email === email)
      if (existingEmail) {
        return { success: false, error: "Email already exists" }
      }
    }

    const newUser: UserWithStats = {
      id: `user-${Date.now()}`,
      username,
      name,
      email: email || undefined,
      role,
      department: department || undefined,
      status: "ACTIVE",
      createdAt: new Date(),
      updatedAt: new Date(),
      permissions: getDefaultPermissions(role),
    }

    mockUsers.push(newUser)

    await new Promise((resolve) => setTimeout(resolve, 300))

    return { success: true, data: newUser }
  } catch (error) {
    console.error("Error creating user:", error)
    return { success: false, error: "Failed to create user" }
  }
}

// Update user
export async function updateUserAction(id: string, formData: FormData): Promise<UserActionResponse<UserWithStats>> {
  try {
    const name = formData.get("name") as string
    const email = formData.get("email") as string
    const role = formData.get("role") as Role
    const department = formData.get("department") as string

    if (!name) {
      return { success: false, error: "Name is required" }
    }

    const userIndex = mockUsers.findIndex((u) => u.id === id)
    if (userIndex === -1) {
      return { success: false, error: "User not found" }
    }

    // Check if email already exists (if being updated)
    if (email) {
      const existingEmail = mockUsers.find((u) => u.email === email && u.id !== id)
      if (existingEmail) {
        return { success: false, error: "Email already exists" }
      }
    }

    mockUsers[userIndex] = {
      ...mockUsers[userIndex],
      name,
      email: email || undefined,
      role,
      department: department || undefined,
      updatedAt: new Date(),
    }

    await new Promise((resolve) => setTimeout(resolve, 300))

    return { success: true, data: mockUsers[userIndex] }
  } catch (error) {
    console.error("Error updating user:", error)
    return { success: false, error: "Failed to update user" }
  }
}

// Delete user
export async function deleteUserAction(id: string): Promise<UserActionResponse<boolean>> {
  try {
    const userIndex = mockUsers.findIndex((u) => u.id === id)
    if (userIndex === -1) {
      return { success: false, error: "User not found" }
    }

    // For demo purposes, we'll just mark as inactive instead of deleting
    mockUsers[userIndex].status = "INACTIVE"
    mockUsers[userIndex].updatedAt = new Date()

    await new Promise((resolve) => setTimeout(resolve, 300))

    return { success: true, data: true }
  } catch (error) {
    console.error("Error deleting user:", error)
    return { success: false, error: "Failed to delete user" }
  }
}

// Toggle user status
export async function toggleUserStatusAction(id: string): Promise<UserActionResponse<UserWithStats>> {
  try {
    const userIndex = mockUsers.findIndex((u) => u.id === id)
    if (userIndex === -1) {
      return { success: false, error: "User not found" }
    }

    const newStatus = mockUsers[userIndex].status === "ACTIVE" ? "INACTIVE" : "ACTIVE"
    mockUsers[userIndex].status = newStatus
    mockUsers[userIndex].updatedAt = new Date()

    await new Promise((resolve) => setTimeout(resolve, 300))

    return { success: true, data: mockUsers[userIndex] }
  } catch (error) {
    console.error("Error toggling user status:", error)
    return { success: false, error: "Failed to update user status" }
  }
}

// Get user statistics
export async function getUserStatsAction() {
  try {
    const activeUsers = mockUsers.filter((u) => u.status === "ACTIVE")
    const totalUsers = activeUsers.length

    const usersByRole = activeUsers.reduce(
      (acc, user) => {
        acc[user.role] = (acc[user.role] || 0) + 1
        return acc
      },
      {} as Record<Role, number>,
    )

    const usersByDepartment = activeUsers.reduce(
      (acc, user) => {
        if (user.department) {
          acc[user.department] = (acc[user.department] || 0) + 1
        }
        return acc
      },
      {} as Record<string, number>,
    )

    await new Promise((resolve) => setTimeout(resolve, 200))

    return {
      success: true,
      data: {
        total: totalUsers,
        byRole: usersByRole,
        byDepartment: usersByDepartment,
      },
    }
  } catch (error) {
    console.error("Error getting user stats:", error)
    return { success: false, error: "Failed to get user statistics" }
  }
}

// Helper function to get default permissions based on role
function getDefaultPermissions(role: Role): any {
  const permissions = {
    ADMIN: [
      "user_management",
      "display_management",
      "content_management",
      "emergency_alerts",
      "system_settings",
      "analytics",
    ],
    DOCTOR: ["patient_management", "appointments", "prescriptions", "medical_records"],
    NURSE: ["patient_care", "appointments", "medication_administration"],
    TECHNICIAN: ["equipment_management", "maintenance", "technical_support"],
    PHARMACIST: ["drug_inventory", "prescriptions", "medication_dispensing"],
    PATIENT: ["view_appointments", "view_prescriptions", "personal_records"],
  }

  return permissions[role] || []
}
