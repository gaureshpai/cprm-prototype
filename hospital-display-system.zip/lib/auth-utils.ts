import type { User } from "./interfaces"

// Storage keys
export const AUTH_STORAGE_KEY = "udal_auth_user"
export const SESSION_STORAGE_KEY = "udal_session"

// Session duration (24 hours for remember me, 8 hours for regular)
export const SESSION_DURATION = {
  REGULAR: 8 * 60 * 60 * 1000, // 8 hours
  REMEMBER_ME: 24 * 60 * 60 * 1000, // 24 hours
}

// Secure storage utilities
export const secureStorage = {
  set: (key: string, value: any, rememberMe = false) => {
    try {
      const data = {
        value,
        timestamp: Date.now(),
        expiresAt: Date.now() + (rememberMe ? SESSION_DURATION.REMEMBER_ME : SESSION_DURATION.REGULAR),
      }

      if (rememberMe) {
        localStorage.setItem(key, JSON.stringify(data))
      } else {
        sessionStorage.setItem(key, JSON.stringify(data))
      }
    } catch (error) {
      console.error("Failed to save to storage:", error)
    }
  },

  get: (key: string) => {
    try {
      // Try sessionStorage first, then localStorage
      const stored = sessionStorage.getItem(key) || localStorage.getItem(key)

      if (!stored) return null

      const data = JSON.parse(stored)

      // Check if expired
      if (data.expiresAt && Date.now() > data.expiresAt) {
        secureStorage.remove(key)
        return null
      }

      return data.value
    } catch (error) {
      console.error("Failed to read from storage:", error)
      return null
    }
  },

  remove: (key: string) => {
    try {
      localStorage.removeItem(key)
      sessionStorage.removeItem(key)
    } catch (error) {
      console.error("Failed to remove from storage:", error)
    }
  },

  clear: () => {
    try {
      localStorage.removeItem(AUTH_STORAGE_KEY)
      localStorage.removeItem(SESSION_STORAGE_KEY)
      sessionStorage.removeItem(AUTH_STORAGE_KEY)
      sessionStorage.removeItem(SESSION_STORAGE_KEY)
    } catch (error) {
      console.error("Failed to clear storage:", error)
    }
  },
}

// User validation
export const validateUser = (user: any): user is User => {
  return (
    user &&
    typeof user.id === "string" &&
    typeof user.username === "string" &&
    typeof user.name === "string" &&
    typeof user.role === "string" &&
    Array.isArray(user.permissions) &&
    typeof user.status === "string"
  )
}

// Permission checking utilities
export const checkPermission = (user: User | null, permission: string): boolean => {
  if (!user || user.status !== "ACTIVE") return false
  return user.permissions.includes(permission) || user.role === "ADMIN"
}

export const checkRole = (user: User | null, roles: string | string[]): boolean => {
  if (!user || user.status !== "ACTIVE") return false
  const roleArray = Array.isArray(roles) ? roles : [roles]
  return roleArray.includes(user.role)
}

// Session management
export const isSessionValid = (user: User | null): boolean => {
  if (!user) return false

  if (user.sessionExpiry) {
    return new Date(user.sessionExpiry) > new Date()
  }

  return true
}

export const refreshSession = (user: User, rememberMe = false): User => {
  const expiryTime = new Date(Date.now() + (rememberMe ? SESSION_DURATION.REMEMBER_ME : SESSION_DURATION.REGULAR))

  return {
    ...user,
    sessionExpiry: expiryTime.toISOString(),
    lastLogin: new Date().toISOString(),
  }
}
