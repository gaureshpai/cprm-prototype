import { type NextRequest, NextResponse } from "next/server"
import { DisplayService } from "@/lib/display-service"

export async function GET() {
  try {
    const result = await DisplayService.getAllDisplays()

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 })
    }

    return NextResponse.json({ displays: result.data })
  } catch (error) {
    console.error("Error in GET /api/displays:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { location, content, status, config } = body

    if (!location) {
      return NextResponse.json({ error: "Location is required" }, { status: 400 })
    }

    const result = await DisplayService.createDisplay({
      location,
      content,
      status,
      config,
    })

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 })
    }

    return NextResponse.json({ display: result.data }, { status: 201 })
  } catch (error) {
    console.error("Error in POST /api/displays:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
