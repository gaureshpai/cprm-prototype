import { type NextRequest, NextResponse } from "next/server"
import { DisplayService } from "@/lib/display-service"
import getDisplayById from "@/lib/display-service"

interface RouteParams {
  params: Promise<{ id: string }>
}

export async function GET(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params
    const result = await getDisplayById(id)

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 404 })
    }

    return NextResponse.json({ display: result.data })
  } catch (error) {
    console.error("Error in GET /api/displays/[id]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params
    const body = await request.json()
    const { location, content, status, config, isActive } = body

    const result = await DisplayService.updateDisplay(id, {
      location,
      content,
      status,
      config,
      isActive,
    })

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 })
    }

    return NextResponse.json({ display: result.data })
  } catch (error) {
    console.error("Error in PUT /api/displays/[id]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: RouteParams) {
  try {
    const { id } = await params
    const result = await DisplayService.deleteDisplay(id)

    if (!result.success) {
      return NextResponse.json({ error: result.error }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error in DELETE /api/displays/[id]:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
