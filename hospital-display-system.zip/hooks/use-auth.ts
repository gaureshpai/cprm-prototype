"use client"

import { useState, useEffect } from "react"

interface User {
  id: string
  name: string
  email: string
  role: string
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, you would check for a session or token
    // For now, we'll simulate a logged-in admin user
    const mockUser = {
      id: "user-1",
      name: "Admin User",
      email: "admin@hospital.com",
      role: "admin",
    }

    setUser(mockUser)
    setLoading(false)
  }, [])

  const login = async (email: string, password: string) => {
    // In a real app, you would make an API call to authenticate
    setUser({
      id: "user-1",
      name: "Admin User",
      email,
      role: "admin",
    })
    return true
  }

  const logout = () => {
    // In a real app, you would clear the session or token
    setUser(null)
  }

  return {
    user,
    loading,
    login,
    logout,
  }
}
