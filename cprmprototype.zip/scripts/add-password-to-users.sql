-- Add password column to User table
ALTER TABLE "User" ADD COLUMN "password" VARCHAR(255);

-- Update existing users with default passwords
UPDATE "User" SET "password" = 'admin123' WHERE "role" = 'ADMIN';
UPDATE "User" SET "password" = 'doctor123' WHERE "role" = 'DOCTOR';
UPDATE "User" SET "password" = 'nurse123' WHERE "role" = 'NURSE';
UPDATE "User" SET "password" = 'tech123' WHERE "role" = 'TECHNICIAN';
UPDATE "User" SET "password" = 'pharma123' WHERE "role" = 'PHARMACIST';
UPDATE "User" SET "password" = 'patient123' WHERE "role" = 'PATIENT';

-- Make password column NOT NULL after setting default values
ALTER TABLE "User" ALTER COLUMN "password" SET NOT NULL;

-- Create some test users with passwords
INSERT INTO "User" (id, username, name, email, password, role, department, status, permissions, "createdAt", "updatedAt")
VALUES 
  (gen_random_uuid(), 'admin', 'System Administrator', 'admin@hospital.com', 'admin123', 'ADMIN', 'IT', 'ACTIVE', '["user_management", "display_management", "content_management", "emergency_alerts", "system_settings", "analytics"]', NOW(), NOW()),
  (gen_random_uuid(), 'dr.smith', 'Dr. John Smith', 'dr.smith@hospital.com', 'doctor123', 'DOCTOR', 'Cardiology', 'ACTIVE', '["patient_management", "appointments", "prescriptions", "medical_records"]', NOW(), NOW()),
  (gen_random_uuid(), 'nurse.mary', 'Mary Johnson', 'mary@hospital.com', 'nurse123', 'NURSE', 'Emergency', 'ACTIVE', '["patient_care", "appointments", "medication_administration"]', NOW(), NOW()),
  (gen_random_uuid(), 'tech.bob', 'Bob Wilson', 'bob@hospital.com', 'tech123', 'TECHNICIAN', 'IT', 'ACTIVE', '["equipment_management", "maintenance", "technical_support"]', NOW(), NOW()),
  (gen_random_uuid(), 'pharma.lisa', 'Lisa Davis', 'lisa@hospital.com', 'pharma123', 'PHARMACIST', 'Pharmacy', 'ACTIVE', '["drug_inventory", "prescriptions", "medication_dispensing"]', NOW(), NOW())
ON CONFLICT (username) DO NOTHING;
