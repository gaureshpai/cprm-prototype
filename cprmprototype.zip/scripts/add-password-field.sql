-- Add password field to existing users (for prototype - no hashing)
-- Run this after updating the schema

-- Update existing users with default passwords based on their usernames
UPDATE users SET password = 'admin123' WHERE role = 'ADMIN';
UPDATE users SET password = 'doctor123' WHERE role = 'DOCTOR';
UPDATE users SET password = 'nurse123' WHERE role = 'NURSE';
UPDATE users SET password = 'tech123' WHERE role = 'TECHNICIAN';
UPDATE users SET password = 'pharma123' WHERE role = 'PHARMACIST';
UPDATE users SET password = 'patient123' WHERE role = 'PATIENT';

-- Create some sample users with passwords for testing
INSERT INTO users (id, username, name, email, password, role, department, status, permissions, created_at, updated_at)
VALUES 
  ('test-admin-1', 'admin', 'System Administrator', 'admin@wenlock.hospital', 'admin123', 'ADMIN', 'IT', 'ACTIVE', '["user_management", "display_management", "content_management", "emergency_alerts", "system_settings", "analytics"]', NOW(), NOW()),
  ('test-doctor-1', 'dr.smith', 'Dr. John Smith', 'dr.smith@wenlock.hospital', 'doctor123', 'DOCTOR', 'Cardiology', 'ACTIVE', '["patient_management", "appointments", "prescriptions", "medical_records"]', NOW(), NOW()),
  ('test-nurse-1', 'nurse.mary', 'Mary Johnson', 'nurse.mary@wenlock.hospital', 'nurse123', 'NURSE', 'Emergency', 'ACTIVE', '["patient_care", "appointments", "medication_administration"]', NOW(), NOW()),
  ('test-tech-1', 'tech.bob', 'Bob Wilson', 'tech.bob@wenlock.hospital', 'tech123', 'TECHNICIAN', 'Maintenance', 'ACTIVE', '["equipment_management", "maintenance", "technical_support"]', NOW(), NOW()),
  ('test-pharma-1', 'pharma.lisa', 'Lisa Davis', 'pharma.lisa@wenlock.hospital', 'pharma123', 'PHARMACIST', 'Pharmacy', 'ACTIVE', '["drug_inventory", "prescriptions", "medication_dispensing"]', NOW(), NOW())
ON CONFLICT (username) DO UPDATE SET
  password = EXCLUDED.password,
  updated_at = NOW();
