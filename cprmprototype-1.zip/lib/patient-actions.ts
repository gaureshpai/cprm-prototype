"use server"

import { revalidatePath } from "next/cache"
import {
  getPatientById,
  searchPatientById,
  getPatientAppointments,
  getPatientMedications,
  getPatientStats,
  updatePatientVitals,
  type PatientDetailsData,
} from "./patient-service"
import type { PatientData } from "./doctor-actions"

export type { PatientDetailsData }

export async function getPatientByIdAction(patientId: string) {
  try {
    const patient = await getPatientById(patientId)

    if (!patient) {
      return {
        success: false,
        error: "Patient not found",
        data: null,
      }
    }

    return {
      success: true,
      data: patient,
      error: null,
    }
  } catch (error) {
    console.error("Error in getPatientByIdAction:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to fetch patient",
      data: null,
    }
  }
}

export async function searchPatientByIdAction(patientId: string) {
  try {
    if (!patientId || patientId.trim().length === 0) {
      return {
        success: false,
        error: "Patient ID is required",
        data: null,
      }
    }

    const patient = await searchPatientById(patientId.trim())

    if (!patient) {
      return {
        success: false,
        error: "No patient found with the provided ID",
        data: null,
      }
    }

    return {
      success: true,
      data: patient,
      error: null,
    }
  } catch (error) {
    console.error("Error in searchPatientByIdAction:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to search patient",
      data: null,
    }
  }
}

export async function getPatientAppointmentsAction(patientId: string, limit = 20) {
  try {
    const appointments = await getPatientAppointments(patientId, limit)

    return {
      success: true,
      data: appointments,
      error: null,
    }
  } catch (error) {
    console.error("Error in getPatientAppointmentsAction:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to fetch appointments",
      data: [],
    }
  }
}

export async function getPatientMedicationsAction(patientId: string, limit = 20) {
  try {
    const medications = await getPatientMedications(patientId, limit)

    return {
      success: true,
      data: medications,
      error: null,
    }
  } catch (error) {
    console.error("Error in getPatientMedicationsAction:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to fetch medications",
      data: [],
    }
  }
}

export async function getPatientStatsAction(patientId: string) {
  try {
    const stats = await getPatientStats(patientId)

    return {
      success: true,
      data: stats,
      error: null,
    }
  } catch (error) {
    console.error("Error in getPatientStatsAction:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to fetch patient statistics",
      data: null,
    }
  }
}

export async function updatePatientVitalsAction(formData: FormData) {
  try {
    const patientId = formData.get("patientId") as string
    const bp = formData.get("bp") as string
    const pulse = formData.get("pulse") as string
    const temp = formData.get("temp") as string
    const weight = formData.get("weight") as string
    const height = formData.get("height") as string

    if (!patientId) {
      return {
        success: false,
        error: "Patient ID is required",
        data: null,
      }
    }

    const vitals = {
      bp: bp || undefined,
      pulse: pulse || undefined,
      temp: temp || undefined,
      weight: weight || undefined,
      height: height || undefined,
    }

    const updatedPatient = await updatePatientVitals(patientId, vitals)

    revalidatePath("/")

    return {
      success: true,
      data: updatedPatient,
      error: null,
    }
  } catch (error) {
    console.error("Error in updatePatientVitalsAction:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to update patient vitals",
      data: null,
    }
  }
}

export async function getAllPatientsAction(page = 1, limit = 50, search?: string) {
  try {
    // Convert mock data to PatientData format
    const patients = await searchPatients(search || "", limit)

    // Transform mock data to match PatientData interface
    const transformedPatients: PatientData[] = patients.map((patient) => ({
      id: patient.id,
      name: patient.name,
      age: patient.age,
      gender: patient.gender,
      phone: patient.phone,
      address: patient.address,
      condition: patient.condition,
      status: patient.status,
      lastVisit: patient.lastVisit ? new Date(patient.lastVisit) : null,
      nextAppointment: patient.nextAppointment ? new Date(patient.nextAppointment) : null,
      createdAt: patient.createdAt,
      updatedAt: patient.updatedAt,
      vitals: patient.vitals,
      medications: patient.medications,
      allergies: patient.allergies,
      medicalHistory: patient.medicalHistory,
      bloodType: patient.bloodType,
      emergencyContact: patient.emergencyContact,
      emergencyPhone: patient.emergencyPhone,
    }))

    return {
      success: true,
      data: {
        patients: transformedPatients,
        total: transformedPatients.length,
        page: page,
        limit: limit,
        totalPages: Math.ceil(transformedPatients.length / limit),
      },
      error: null,
    }
  } catch (error) {
    console.error("Error in getAllPatientsAction:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to fetch patients",
      data: null,
    }
  }
}

export async function deletePatientAction(patientId: string) {
  try {
    if (!patientId || patientId.trim().length === 0) {
      return {
        success: false,
        error: "Patient ID is required",
        data: null,
      }
    }

    // In a real implementation, this would soft delete or deactivate the patient
    // For now, we'll simulate a successful deletion
    const result = await updatePatientStatus(patientId, "Inactive")

    if (!result) {
      return {
        success: false,
        error: "Patient not found or could not be deactivated",
        data: null,
      }
    }

    revalidatePath("/doctor/patients")

    return {
      success: true,
      data: result,
      error: null,
    }
  } catch (error) {
    console.error("Error in deletePatientAction:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to delete patient",
      data: null,
    }
  }
}

// Helper functions
async function searchPatients(query: string, limit: number) {
  // Import mock data
  const { mockPatients } = await import("@/lib/mock-data")

  if (!query) {
    return mockPatients.slice(0, limit)
  }

  const filtered = mockPatients.filter(
    (patient) =>
      patient.name.toLowerCase().includes(query.toLowerCase()) ||
      patient.id.toLowerCase().includes(query.toLowerCase()) ||
      (patient.condition && patient.condition.toLowerCase().includes(query.toLowerCase())) ||
      (patient.phone && patient.phone.includes(query)),
  )

  return filtered.slice(0, limit)
}

async function updatePatientStatus(patientId: string, status: string) {
  // This would typically update the database
  // For now, we'll simulate the update
  const { mockPatients } = await import("@/lib/mock-data")
  const patient = mockPatients.find((p) => p.id === patientId)

  if (patient) {
    return { ...patient, status, updatedAt: new Date() }
  }

  return null
}
