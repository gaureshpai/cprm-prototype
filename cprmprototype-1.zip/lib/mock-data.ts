export interface MockPatientData {
  id: string
  name: string
  age: number
  gender: string
  phone: string
  address: string
  condition: string
  status: string
  lastVisit: string
  nextAppointment: string
  createdAt: Date
  updatedAt: Date
  vitals: {
    bp: string
    pulse: string
    temp: string
    weight: string
    height: string
  }
  medications: {
    id: string
    name: string
    dosage: string
    frequency: string
    duration: string
    instructions?: string
    drugInfo: {
      id: string
      currentStock: number
      minStock: number
      status: string
      category?: string
      batchNumber?: string
      expiryDate?: Date
      location: string
    }
    prescriptionDate: Date
  }[]
  allergies: string[]
  medicalHistory: {
    id: string
    diagnosis: string
    treatment: string
    date: string
    doctorName: string
  }[]
  bloodType?: string
  emergencyContact?: string
  emergencyPhone?: string
}

export const mockPatients: MockPatientData[] = [
  {
    id: "P001",
    name: "John Smith",
    age: 45,
    gender: "Male",
    phone: "+91-9876543210",
    address: "123 MG Road, Bangalore, Karnataka 560001",
    condition: "Hypertension",
    status: "Active",
    lastVisit: "2024-01-15",
    nextAppointment: "2024-02-15",
    createdAt: new Date("2023-06-15"),
    updatedAt: new Date("2024-01-15"),
    bloodType: "O+",
    emergencyContact: "Jane Smith",
    emergencyPhone: "+91-9876543211",
    vitals: {
      bp: "140/90",
      pulse: "78",
      temp: "98.6°F",
      weight: "75 kg",
      height: "5'8\"",
    },
    medications: [
      {
        id: "MED001",
        name: "Amlodipine",
        dosage: "5mg",
        frequency: "1-0-0",
        duration: "30 days",
        instructions: "Take with food",
        prescriptionDate: new Date("2024-01-15"),
        drugInfo: {
          id: "DRUG001",
          currentStock: 150,
          minStock: 20,
          status: "Available",
          category: "Antihypertensive",
          batchNumber: "AMB2024001",
          expiryDate: new Date("2025-12-31"),
          location: "Pharmacy-A1",
        },
      },
      {
        id: "MED002",
        name: "Metoprolol",
        dosage: "25mg",
        frequency: "1-0-1",
        duration: "30 days",
        instructions: "Take before meals",
        prescriptionDate: new Date("2024-01-15"),
        drugInfo: {
          id: "DRUG002",
          currentStock: 80,
          minStock: 15,
          status: "Available",
          category: "Beta Blocker",
          batchNumber: "MET2024001",
          expiryDate: new Date("2025-10-31"),
          location: "Pharmacy-A2",
        },
      },
    ],
    allergies: ["Penicillin", "Shellfish"],
    medicalHistory: [
      {
        id: "HIST001",
        diagnosis: "Hypertension Stage 1",
        treatment: "Lifestyle modification + Medication",
        date: "2024-01-15",
        doctorName: "Dr. Rajesh Kumar",
      },
      {
        id: "HIST002",
        diagnosis: "Annual Health Checkup",
        treatment: "Routine blood work, ECG normal",
        date: "2023-12-01",
        doctorName: "Dr. Priya Sharma",
      },
    ],
  },
  {
    id: "P002",
    name: "Sarah Johnson",
    age: 32,
    gender: "Female",
    phone: "+91-9876543220",
    address: "456 Brigade Road, Bangalore, Karnataka 560025",
    condition: "Type 2 Diabetes",
    status: "Active",
    lastVisit: "2024-01-20",
    nextAppointment: "2024-02-20",
    createdAt: new Date("2023-08-10"),
    updatedAt: new Date("2024-01-20"),
    bloodType: "A+",
    emergencyContact: "Michael Johnson",
    emergencyPhone: "+91-9876543221",
    vitals: {
      bp: "125/80",
      pulse: "72",
      temp: "98.4°F",
      weight: "65 kg",
      height: "5'4\"",
    },
    medications: [
      {
        id: "MED003",
        name: "Metformin",
        dosage: "500mg",
        frequency: "1-0-1",
        duration: "90 days",
        instructions: "Take with meals",
        prescriptionDate: new Date("2024-01-20"),
        drugInfo: {
          id: "DRUG003",
          currentStock: 200,
          minStock: 30,
          status: "Available",
          category: "Antidiabetic",
          batchNumber: "MET2024002",
          expiryDate: new Date("2026-03-31"),
          location: "Pharmacy-B1",
        },
      },
      {
        id: "MED004",
        name: "Glimepiride",
        dosage: "2mg",
        frequency: "1-0-0",
        duration: "90 days",
        instructions: "Take before breakfast",
        prescriptionDate: new Date("2024-01-20"),
        drugInfo: {
          id: "DRUG004",
          currentStock: 120,
          minStock: 25,
          status: "Available",
          category: "Antidiabetic",
          batchNumber: "GLI2024001",
          expiryDate: new Date("2025-08-31"),
          location: "Pharmacy-B2",
        },
      },
    ],
    allergies: ["Sulfa drugs"],
    medicalHistory: [
      {
        id: "HIST003",
        diagnosis: "Type 2 Diabetes Mellitus",
        treatment: "Metformin + Lifestyle counseling",
        date: "2024-01-20",
        doctorName: "Dr. Anjali Mehta",
      },
      {
        id: "HIST004",
        diagnosis: "Gestational Diabetes (Resolved)",
        treatment: "Diet control during pregnancy",
        date: "2022-05-15",
        doctorName: "Dr. Sunita Rao",
      },
    ],
  },
  {
    id: "P003",
    name: "Michael Brown",
    age: 28,
    gender: "Male",
    phone: "+91-9876543230",
    address: "789 Commercial Street, Bangalore, Karnataka 560001",
    condition: "Asthma",
    status: "Admitted",
    lastVisit: "2024-01-25",
    nextAppointment: "2024-02-10",
    createdAt: new Date("2023-09-20"),
    updatedAt: new Date("2024-01-25"),
    bloodType: "B+",
    emergencyContact: "Lisa Brown",
    emergencyPhone: "+91-9876543231",
    vitals: {
      bp: "118/75",
      pulse: "85",
      temp: "99.2°F",
      weight: "70 kg",
      height: "5'10\"",
    },
    medications: [
      {
        id: "MED005",
        name: "Salbutamol Inhaler",
        dosage: "2 puffs",
        frequency: "As needed",
        duration: "30 days",
        instructions: "Use during breathing difficulty",
        prescriptionDate: new Date("2024-01-25"),
        drugInfo: {
          id: "DRUG005",
          currentStock: 45,
          minStock: 10,
          status: "Available",
          category: "Bronchodilator",
          batchNumber: "SAL2024001",
          expiryDate: new Date("2025-06-30"),
          location: "Pharmacy-C1",
        },
      },
      {
        id: "MED006",
        name: "Budesonide Inhaler",
        dosage: "1 puff",
        frequency: "1-0-1",
        duration: "30 days",
        instructions: "Rinse mouth after use",
        prescriptionDate: new Date("2024-01-25"),
        drugInfo: {
          id: "DRUG006",
          currentStock: 30,
          minStock: 8,
          status: "Available",
          category: "Corticosteroid",
          batchNumber: "BUD2024001",
          expiryDate: new Date("2025-04-30"),
          location: "Pharmacy-C2",
        },
      },
    ],
    allergies: ["Dust mites", "Pollen"],
    medicalHistory: [
      {
        id: "HIST005",
        diagnosis: "Acute Asthma Exacerbation",
        treatment: "Nebulization + Oral steroids",
        date: "2024-01-25",
        doctorName: "Dr. Vikram Singh",
      },
      {
        id: "HIST006",
        diagnosis: "Allergic Asthma",
        treatment: "Controller therapy initiated",
        date: "2023-09-20",
        doctorName: "Dr. Neha Gupta",
      },
    ],
  },
  {
    id: "P004",
    name: "Emily Davis",
    age: 38,
    gender: "Female",
    phone: "+91-9876543240",
    address: "321 Residency Road, Bangalore, Karnataka 560025",
    condition: "Migraine",
    status: "Active",
    lastVisit: "2024-01-18",
    nextAppointment: "2024-03-18",
    createdAt: new Date("2023-11-05"),
    updatedAt: new Date("2024-01-18"),
    bloodType: "AB+",
    emergencyContact: "David Davis",
    emergencyPhone: "+91-9876543241",
    vitals: {
      bp: "110/70",
      pulse: "68",
      temp: "98.2°F",
      weight: "58 kg",
      height: "5'6\"",
    },
    medications: [
      {
        id: "MED007",
        name: "Sumatriptan",
        dosage: "50mg",
        frequency: "As needed",
        duration: "30 days",
        instructions: "Take at onset of migraine",
        prescriptionDate: new Date("2024-01-18"),
        drugInfo: {
          id: "DRUG007",
          currentStock: 60,
          minStock: 12,
          status: "Available",
          category: "Antimigraine",
          batchNumber: "SUM2024001",
          expiryDate: new Date("2025-09-30"),
          location: "Pharmacy-D1",
        },
      },
      {
        id: "MED008",
        name: "Propranolol",
        dosage: "40mg",
        frequency: "0-1-0",
        duration: "90 days",
        instructions: "Take for prevention",
        prescriptionDate: new Date("2024-01-18"),
        drugInfo: {
          id: "DRUG008",
          currentStock: 90,
          minStock: 20,
          status: "Available",
          category: "Beta Blocker",
          batchNumber: "PRO2024001",
          expiryDate: new Date("2025-11-30"),
          location: "Pharmacy-D2",
        },
      },
    ],
    allergies: ["Aspirin"],
    medicalHistory: [
      {
        id: "HIST007",
        diagnosis: "Chronic Migraine",
        treatment: "Preventive therapy + Acute treatment",
        date: "2024-01-18",
        doctorName: "Dr. Ravi Krishnan",
      },
      {
        id: "HIST008",
        diagnosis: "Tension Headache",
        treatment: "Stress management counseling",
        date: "2023-11-05",
        doctorName: "Dr. Meera Nair",
      },
    ],
  },
  {
    id: "P005",
    name: "Robert Wilson",
    age: 55,
    gender: "Male",
    phone: "+91-9876543250",
    address: "654 Koramangala, Bangalore, Karnataka 560034",
    condition: "Rheumatoid Arthritis",
    status: "Active",
    lastVisit: "2024-01-22",
    nextAppointment: "2024-02-22",
    createdAt: new Date("2023-07-12"),
    updatedAt: new Date("2024-01-22"),
    bloodType: "O-",
    emergencyContact: "Margaret Wilson",
    emergencyPhone: "+91-9876543251",
    vitals: {
      bp: "135/85",
      pulse: "75",
      temp: "98.8°F",
      weight: "80 kg",
      height: "5'9\"",
    },
    medications: [
      {
        id: "MED009",
        name: "Methotrexate",
        dosage: "15mg",
        frequency: "Once weekly",
        duration: "90 days",
        instructions: "Take with folic acid",
        prescriptionDate: new Date("2024-01-22"),
        drugInfo: {
          id: "DRUG009",
          currentStock: 40,
          minStock: 8,
          status: "Available",
          category: "DMARD",
          batchNumber: "MTX2024001",
          expiryDate: new Date("2025-07-31"),
          location: "Pharmacy-E1",
        },
      },
      {
        id: "MED010",
        name: "Folic Acid",
        dosage: "5mg",
        frequency: "Once weekly",
        duration: "90 days",
        instructions: "Take day after methotrexate",
        prescriptionDate: new Date("2024-01-22"),
        drugInfo: {
          id: "DRUG010",
          currentStock: 100,
          minStock: 20,
          status: "Available",
          category: "Vitamin",
          batchNumber: "FOL2024001",
          expiryDate: new Date("2026-01-31"),
          location: "Pharmacy-E2",
        },
      },
    ],
    allergies: ["NSAIDs"],
    medicalHistory: [
      {
        id: "HIST009",
        diagnosis: "Rheumatoid Arthritis",
        treatment: "DMARD therapy + Physiotherapy",
        date: "2024-01-22",
        doctorName: "Dr. Suresh Reddy",
      },
      {
        id: "HIST010",
        diagnosis: "Joint Pain Investigation",
        treatment: "Blood tests + X-rays",
        date: "2023-07-12",
        doctorName: "Dr. Kavitha Rao",
      },
    ],
  },
]

// Export additional mock data for other modules
export const mockDoctors = [
  {
    id: "DOC001",
    name: "Dr. Rajesh Kumar",
    specialization: "Cardiology",
    phone: "+91-9876540001",
    email: "rajesh.kumar@hospital.com",
  },
  {
    id: "DOC002",
    name: "Dr. Priya Sharma",
    specialization: "Internal Medicine",
    phone: "+91-9876540002",
    email: "priya.sharma@hospital.com",
  },
  {
    id: "DOC003",
    name: "Dr. Anjali Mehta",
    specialization: "Endocrinology",
    phone: "+91-9876540003",
    email: "anjali.mehta@hospital.com",
  },
]

export const mockDrugs = [
  {
    id: "DRUG001",
    drugName: "Amlodipine",
    currentStock: 150,
    minStock: 20,
    status: "Available",
    category: "Antihypertensive",
    location: "Pharmacy-A1",
    isAvailable: true,
  },
  {
    id: "DRUG002",
    drugName: "Metoprolol",
    currentStock: 80,
    minStock: 15,
    status: "Available",
    category: "Beta Blocker",
    location: "Pharmacy-A2",
    isAvailable: true,
  },
  {
    id: "DRUG003",
    drugName: "Metformin",
    currentStock: 200,
    minStock: 30,
    status: "Available",
    category: "Antidiabetic",
    location: "Pharmacy-B1",
    isAvailable: true,
  },
  {
    id: "DRUG004",
    drugName: "Glimepiride",
    currentStock: 120,
    minStock: 25,
    status: "Available",
    category: "Antidiabetic",
    location: "Pharmacy-B2",
    isAvailable: true,
  },
  {
    id: "DRUG005",
    drugName: "Salbutamol Inhaler",
    currentStock: 45,
    minStock: 10,
    status: "Available",
    category: "Bronchodilator",
    location: "Pharmacy-C1",
    isAvailable: true,
  },
]
