// Utility functions for fetching and processing CSV data

export async function fetchCSVData(url: string) {
  try {
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`Failed to fetch data: ${response.status} ${response.statusText}`)
    }

    const text = await response.text()
    return parseCSV(text)
  } catch (error) {
    console.error("Error fetching CSV data:", error)
    return []
  }
}

function parseCSV(text: string) {
  const lines = text.split("\n")
  const headers = lines[0].split(",").map((header) => header.trim())

  return lines
    .slice(1)
    .filter((line) => line.trim() !== "")
    .map((line) => {
      const values = line.split(",").map((value) => value.trim())
      const record: Record<string, string> = {}

      headers.forEach((header, index) => {
        record[header] = values[index] || ""
      })

      return record
    })
}

export const CSV_URLS = {
  drugInventory:
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/drug_inventory-7DWS7ecKq6YwOhHZ4bLEsmI2hPKc7H.csv",
  tokenQueue: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/token_queue-8mvlHESqCgThzd88VO8DwPVMpGXar8.csv",
  departments: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/departments-mxE8kPtKolY8CrvG5uOmKgg9y7mnaW.csv",
  bloodBank: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/blood_bank-vmYJDHD8UQZmoAE1I4n4JKWfL9nXMW.csv",
  emergencyAlerts:
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/emergency_alerts-iHDlIUNzRNnrB0iycyNzJQJqt1zd2a.csv",
}

export interface DrugInventory {
  drug_id: string
  drug_name: string
  stock_qty: string
  reorder_level: string
  status: string
}

export interface TokenQueue {
  token_id: string
  dept_id: string
  patient_name: string
  status: string
}

export interface Department {
  dept_id: string
  department_name: string
  location: string
}

export interface BloodBank {
  blood_id: string
  blood_type: string
  units_available: string
  critical_level: string
  status: string
}

export interface EmergencyAlert {
  alert_id: string
  code_type: string
  department: string
  timestamp: string
  status: string
}

// Function to get status color based on inventory status
export function getInventoryStatusColor(status: string) {
  switch (status.toLowerCase()) {
    case "critical":
      return "text-red-600 bg-red-50 border-red-200"
    case "low":
      return "text-yellow-600 bg-yellow-50 border-yellow-200"
    case "available":
      return "text-green-600 bg-green-50 border-green-200"
    default:
      return "text-gray-600 bg-gray-50 border-gray-200"
  }
}

// Function to get status color based on blood bank status
export function getBloodStatusColor(status: string) {
  switch (status.toLowerCase()) {
    case "critical":
      return "text-red-600 bg-red-50 border-red-200"
    case "low":
      return "text-yellow-600 bg-yellow-50 border-yellow-200"
    case "available":
      return "text-green-600 bg-green-50 border-green-200"
    default:
      return "text-gray-600 bg-gray-50 border-gray-200"
  }
}

// Function to get status color based on token status
export function getTokenStatusColor(status: string) {
  switch (status.toLowerCase()) {
    case "in progress":
      return "bg-blue-500"
    case "waiting":
      return "bg-yellow-500"
    case "completed":
      return "bg-green-500"
    case "cancelled":
      return "bg-red-500"
    default:
      return "bg-gray-500"
  }
}

// Function to get status color based on emergency alert status
export function getAlertStatusColor(status: string) {
  switch (status.toLowerCase()) {
    case "active":
      return "bg-red-500"
    case "in progress":
      return "bg-orange-500"
    case "cleared":
      return "bg-green-500"
    default:
      return "bg-gray-500"
  }
}

// Function to get color based on emergency code type
export function getCodeTypeColor(codeType: string) {
  switch (codeType.toLowerCase()) {
    case "code blue":
      return "bg-blue-500"
    case "code red":
      return "bg-red-500"
    case "code pink":
      return "bg-pink-500"
    case "code yellow":
      return "bg-yellow-500"
    default:
      return "bg-gray-500"
  }
}
