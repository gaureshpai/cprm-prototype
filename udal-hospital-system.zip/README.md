# CPRM Prototype - Centralized Patient & Resource Management System

## Problem Statement

Wenlock Hospital currently faces fragmented communication across departments like Cardiology, OT, and Pharmacy. Despite having 73 display screens and a drug inventory system, there's no unified platform to manage OT schedules, display real-time updates, or broadcast emergency alerts.

## Solution Overview

The Centralized Patient & Resource Management System (CPRM) is a comprehensive web application that integrates various hospital departments into a unified platform. It provides real-time synchronization of critical data including:

- OT/Consultation schedules and token queues
- Drug inventory status and alerts
- Blood bank availability
- Emergency alerts (Code Blue/Red)
- Department-specific information

The system features role-based access with specialized dashboards for doctors, nurses, pharmacists, technicians, and administrators, ensuring that each staff member has access to the information they need.

## Key Features

### 1. Real-Time Dashboards
- **Main Dashboard**: Comprehensive overview of hospital operations
- **Department-Specific Views**: Tailored interfaces for each department
- **Display Screen Interface**: Public-facing information displays

### 2. Patient Flow Management
- **Token Queue System**: Real-time tracking of patient queues
- **Waiting Time Estimation**: Dynamic calculation of expected wait times
- **Department Navigation**: Guidance for patients to find their destinations

### 3. Resource Monitoring
- **Drug Inventory Tracking**: Real-time stock levels and alerts
- **Blood Bank Status**: Availability of different blood types
- **OT Status Monitoring**: Current and scheduled operations

### 4. Emergency Response System
- **Alert Broadcasting**: Immediate notification across all displays
- **Code Management**: Standardized protocols for different emergency codes
- **Response Coordination**: Tools for managing emergency situations

### 5. Administrative Tools
- **Display Management**: Control content across 73 display screens
- **User Management**: Role-based access control
- **System Configuration**: Customizable settings for different departments

## Technology Stack

- **Frontend**: Next.js, React, Tailwind CSS, shadcn/ui
- **Backend**: Next.js API Routes, Server Actions
- **State Management**: React Context API, React Hooks
- **Authentication**: JWT-based authentication
- **Real-time Updates**: WebSockets (planned)
- **Data Storage**: CSV files (current), Database integration (planned)

## Installation

1. Clone the repository:
\`\`\`bash
git clone https://github.com/your-username/cprm-prototype.git
cd cprm-prototype
\`\`\`

2. Install dependencies:
\`\`\`bash
npm install
\`\`\`

3. Run the development server:
\`\`\`bash
npm run dev
\`\`\`

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Demo Credentials

| Role       | Username        | Password    |
|------------|----------------|------------|
| Admin      | admin@udal.com  | admin123   |
| Doctor     | doctor@udal.com | doctor123  |
| Nurse      | nurse@udal.com  | nurse123   |
| Pharmacist | pharm@udal.com  | pharm123   |
| Technician | tech@udal.com   | tech123    |

## System Architecture

The CPRM system follows a modular architecture with the following components:

1. **Authentication Module**: Handles user login and role-based access control
2. **Dashboard Module**: Provides customized views based on user roles
3. **Patient Management Module**: Handles token queues and patient information
4. **Resource Management Module**: Tracks inventory, blood bank, and OT status
5. **Alert System**: Manages emergency alerts and notifications
6. **Display Control Module**: Manages content across hospital displays

## Data Flow

1. Data is sourced from departmental systems (currently simulated with CSV files)
2. The central CPRM system processes and integrates this data
3. Real-time updates are pushed to relevant dashboards and displays
4. User actions trigger updates across the system
5. Emergency alerts override normal display content when activated

## Security & Compliance

- Role-based access control ensures data privacy
- Patient information is anonymized on public displays
- Audit logging tracks all system activities
- Compliant with healthcare data protection standards

## Future Enhancements

- Database integration for persistent storage
- Mobile application for staff and patients
- Integration with hospital information systems (HIS)
- Advanced analytics and reporting
- Multilingual support
- Biometric authentication

## Contributors

- UDAL Fellowship Team
- Wenlock Hospital Staff

## License

This project is proprietary and confidential. Unauthorized copying, distribution, or use is strictly prohibited.

---

© 2025 UDAL - Wenlock Hospital Management System
\`\`\`

Now, let's implement the data integration with the provided CSV files:
