"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Activity,
  Users,
  Clock,
  AlertTriangle,
  Heart,
  Stethoscope,
  Pill,
  Monitor,
  UserCheck,
  Bell,
  Shield,
  Zap,
} from "lucide-react"
import {
  fetchCSVData,
  CSV_URLS,
  type DrugInventory,
  type TokenQueue,
  type Department,
  type BloodBank,
  type EmergencyAlert,
  getInventoryStatusColor,
  getBloodStatusColor,
} from "@/lib/data-utils"

export default function UDALDashboard() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [drugInventory, setDrugInventory] = useState<DrugInventory[]>([])
  const [tokenQueue, setTokenQueue] = useState<TokenQueue[]>([])
  const [departments, setDepartments] = useState<Department[]>([])
  const [bloodBank, setBloodBank] = useState<BloodBank[]>([])
  const [emergencyAlerts, setEmergencyAlerts] = useState<EmergencyAlert[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    async function loadData() {
      setLoading(true)
      try {
        const [drugData, tokenData, deptData, bloodData, alertData] = await Promise.all([
          fetchCSVData(CSV_URLS.drugInventory),
          fetchCSVData(CSV_URLS.tokenQueue),
          fetchCSVData(CSV_URLS.departments),
          fetchCSVData(CSV_URLS.bloodBank),
          fetchCSVData(CSV_URLS.emergencyAlerts),
        ])

        setDrugInventory(drugData as DrugInventory[])
        setTokenQueue(tokenData as TokenQueue[])
        setDepartments(deptData as Department[])
        setBloodBank(bloodData as BloodBank[])

        // Filter only active emergency alerts
        const activeAlerts = (alertData as EmergencyAlert[]).filter((alert) => alert.status.toLowerCase() === "active")
        setEmergencyAlerts(activeAlerts)
      } catch (error) {
        console.error("Error loading data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()

    // Simulate real-time updates by refreshing data every 30 seconds
    const dataRefreshInterval = setInterval(() => {
      loadData()
    }, 30000)

    return () => clearInterval(dataRefreshInterval)
  }, [])

  // Calculate statistics
  const criticalDrugs = drugInventory.filter((drug) => drug.status.toLowerCase() === "critical").length
  const lowDrugs = drugInventory.filter((drug) => drug.status.toLowerCase() === "low").length

  const criticalBlood = bloodBank.filter((blood) => blood.status.toLowerCase() === "critical").length
  const lowBlood = bloodBank.filter((blood) => blood.status.toLowerCase() === "low").length

  const inProgressTokens = tokenQueue.filter((token) => token.status.toLowerCase() === "in progress").length
  const waitingTokens = tokenQueue.filter((token) => token.status.toLowerCase() === "waiting").length

  // Mock data for OT status (not provided in CSV)
  const mockOTData = {
    otStatus: [
      {
        id: "OT1",
        patient: "S. Babu",
        procedure: "Cardiac Surgery",
        status: "In Progress",
        startTime: "09:30 AM",
        estimatedEnd: "02:30 PM",
      },
      {
        id: "OT2",
        patient: "A. Rao",
        procedure: "Appendectomy",
        status: "Pre-Op",
        startTime: "11:00 AM",
        estimatedEnd: "01:00 PM",
      },
      {
        id: "OT3",
        patient: "R. Krishnan",
        procedure: "Orthopedic Surgery",
        status: "Post-Op Recovery",
        startTime: "08:00 AM",
        estimatedEnd: "Completed",
      },
    ],
  }

  // Enhance department data with patient counts and wait times (mock data)
  const enhancedDepartments = departments.map((dept) => ({
    ...dept,
    currentPatients: Math.floor(Math.random() * 50) + 10,
    waitTime: `${Math.floor(Math.random() * 30) + 5} min`,
    doctor: `Dr. ${["Kumar", "Sharma", "Nair", "Menon"][Math.floor(Math.random() * 4)]}`,
  }))

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Heart className="h-12 w-12 text-blue-400 animate-pulse mx-auto mb-4" />
          <h1 className="text-xl font-bold text-gray-900">Loading UDAL System...</h1>
          <p className="text-gray-500">Please wait while we fetch the latest data</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Heart className="h-8 w-8 text-blue-400" />
                <div>
                  <h1 className="text-xl font-bold text-gray-900">UDAL</h1>
                  <p className="text-xs text-gray-500">Wenlock Hospital</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-gray-900">{currentTime.toLocaleDateString("en-IN")}</p>
                <p className="text-lg font-bold text-blue-600">{currentTime.toLocaleTimeString("en-IN")}</p>
              </div>
              <Bell className="h-6 w-6 text-gray-400" />
            </div>
          </div>
        </div>
      </header>

      {/* Emergency Alerts */}
      {emergencyAlerts.length > 0 && (
        <div className="bg-red-50 border-b border-red-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-red-600 animate-pulse" />
              <span className="font-medium text-red-800">Emergency Alerts:</span>
              <div className="flex space-x-4">
                {emergencyAlerts.map((alert) => (
                  <Badge key={alert.alert_id} variant="destructive" className="animate-pulse">
                    {alert.code_type} - {alert.department} ({new Date(alert.timestamp).toLocaleTimeString()})
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-white">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="tokens">Token Queue</TabsTrigger>
            <TabsTrigger value="ot">OT Status</TabsTrigger>
            <TabsTrigger value="inventory">Inventory</TabsTrigger>
            <TabsTrigger value="blood">Blood Bank</TabsTrigger>
            <TabsTrigger value="departments">Departments</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-l-4 border-l-blue-400">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Patients</CardTitle>
                  <Users className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{tokenQueue.length}</div>
                  <p className="text-xs text-muted-foreground">{inProgressTokens} currently being served</p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-green-400">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active OTs</CardTitle>
                  <Monitor className="h-4 w-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">3/5</div>
                  <p className="text-xs text-muted-foreground">2 scheduled next</p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-yellow-400">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg Wait Time</CardTitle>
                  <Clock className="h-4 w-4 text-yellow-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">23 min</div>
                  <p className="text-xs text-muted-foreground">-5 min from last hour</p>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-red-400">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Critical Alerts</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-red-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{emergencyAlerts.length}</div>
                  <p className="text-xs text-muted-foreground">Requires immediate attention</p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Status Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="h-5 w-5 text-blue-400" />
                    <span>Department Status</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {enhancedDepartments.slice(0, 4).map((dept, index) => (
                    <div key={dept.dept_id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">{dept.department_name}</p>
                        <p className="text-sm text-gray-600">{dept.doctor}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">{dept.currentPatients} patients</p>
                        <p className="text-xs text-gray-500">~{dept.waitTime} wait</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Pill className="h-5 w-5 text-blue-400" />
                    <span>Critical Inventory</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {drugInventory
                    .filter((drug) => drug.status.toLowerCase() !== "available")
                    .slice(0, 4)
                    .map((drug) => (
                      <div key={drug.drug_id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium">{drug.drug_name}</p>
                          <p className="text-sm text-gray-600">{drug.stock_qty} units remaining</p>
                        </div>
                        <Badge className={getInventoryStatusColor(drug.status)}>{drug.status}</Badge>
                      </div>
                    ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Token Queue Tab */}
          <TabsContent value="tokens" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <UserCheck className="h-5 w-5 text-blue-400" />
                  <span>Current Token Queue</span>
                </CardTitle>
                <CardDescription>Real-time patient queue across all departments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {tokenQueue.map((token, index) => {
                    // Find the department name
                    const department = departments.find((d) => d.dept_id === token.dept_id)

                    return (
                      <div
                        key={token.token_id}
                        className="flex items-center justify-between p-4 border rounded-lg bg-white"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full">
                            <span className="font-bold text-blue-600">{index + 1}</span>
                          </div>
                          <div>
                            <p className="font-medium">{token.patient_name}</p>
                            <p className="text-sm text-gray-600">Token: {token.token_id}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant="outline">{department?.department_name || token.dept_id}</Badge>
                          <p className="text-sm text-gray-600 mt-1">
                            Status: <span className="font-medium">{token.status}</span>
                          </p>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* OT Status Tab */}
          <TabsContent value="ot" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Monitor className="h-5 w-5 text-blue-400" />
                  <span>Operation Theater Status</span>
                </CardTitle>
                <CardDescription>Live updates from all operation theaters</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {mockOTData.otStatus.map((ot) => (
                    <Card key={ot.id} className="border-l-4 border-l-blue-400">
                      <CardHeader>
                        <CardTitle className="text-lg">{ot.id}</CardTitle>
                        <Badge
                          variant={
                            ot.status === "In Progress" ? "default" : ot.status === "Pre-Op" ? "secondary" : "outline"
                          }
                          className={ot.status === "In Progress" ? "bg-green-500" : ""}
                        >
                          {ot.status}
                        </Badge>
                      </CardHeader>
                      <CardContent className="space-y-2">
                        <p className="font-medium">Patient: {ot.patient}</p>
                        <p className="text-sm text-gray-600">Procedure: {ot.procedure}</p>
                        <p className="text-sm text-gray-600">Start: {ot.startTime}</p>
                        <p className="text-sm text-gray-600">Est. End: {ot.estimatedEnd}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Inventory Tab */}
          <TabsContent value="inventory" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Pill className="h-5 w-5 text-blue-400" />
                  <span>Drug Inventory Status</span>
                </CardTitle>
                <CardDescription>Real-time stock levels across all pharmacy units</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {drugInventory.map((drug) => {
                    const stockPercentage =
                      (Number.parseInt(drug.stock_qty) / (Number.parseInt(drug.reorder_level) * 2)) * 100

                    return (
                      <div key={drug.drug_id} className="p-4 border rounded-lg bg-white">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium">{drug.drug_name}</h3>
                          <Badge className={getInventoryStatusColor(drug.status)}>{drug.status}</Badge>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Current Stock: {drug.stock_qty} units</span>
                            <span>Min Required: {drug.reorder_level} units</span>
                          </div>
                          <Progress
                            value={Math.min(stockPercentage, 100)}
                            className={`h-2 ${
                              drug.status.toLowerCase() === "critical"
                                ? "bg-red-100"
                                : drug.status.toLowerCase() === "low"
                                  ? "bg-yellow-100"
                                  : "bg-green-100"
                            }`}
                          />
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Blood Bank Tab */}
          <TabsContent value="blood" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5 text-red-500" />
                  <span>Blood Bank Status</span>
                </CardTitle>
                <CardDescription>Available blood units by type</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {bloodBank.map((blood) => (
                    <Card key={blood.blood_id} className="text-center">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-2xl font-bold text-red-600">{blood.blood_type}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold mb-2">{blood.units_available}</p>
                        <Badge className={getBloodStatusColor(blood.status)}>{blood.status}</Badge>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Departments Tab */}
          <TabsContent value="departments" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {enhancedDepartments.map((dept) => (
                <Card key={dept.dept_id}>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Stethoscope className="h-5 w-5 text-blue-400" />
                      <span>{dept.department_name}</span>
                    </CardTitle>
                    <CardDescription>{dept.location}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Current Patients:</span>
                      <span className="text-2xl font-bold text-blue-600">{dept.currentPatients}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Average Wait Time:</span>
                      <Badge variant="outline">{dept.waitTime}</Badge>
                    </div>
                    <div className="pt-2">
                      <Button className="w-full bg-blue-400 hover:bg-blue-500">View Department Details</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-gray-500">© 2024 UDAL - Wenlock Hospital Management System</p>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="bg-green-50 text-green-700">
                <Shield className="h-3 w-3 mr-1" />
                System Online
              </Badge>
              <Badge variant="outline" className="bg-blue-50 text-blue-700">
                <Zap className="h-3 w-3 mr-1" />
                Real-time Updates
              </Badge>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
