"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, MapPin, Clock, Phone, Heart, Navigation, QrCode, Bell, User, Calendar } from "lucide-react"

export default function MobileApp() {
  const [searchQuery, setSearchQuery] = useState("")
  const [userToken, setUserToken] = useState("T001")
  const [queuePosition, setQueuePosition] = useState(1)
  const [estimatedTime, setEstimatedTime] = useState("5 minutes")

  const quickActions = [
    { icon: <QrCode className="h-6 w-6" />, label: "Scan QR", action: "scan" },
    { icon: <MapPin className="h-6 w-6" />, label: "Find Ward", action: "navigate" },
    { icon: <Phone className="h-6 w-6" />, label: "Emergency", action: "emergency" },
    { icon: <Calendar className="h-6 w-6" />, label: "Appointments", action: "appointments" },
  ]

  const departments = [
    { name: "Cardiology", waitTime: "15 min", doctor: "Dr. Sharath Kumar", available: true },
    { name: "General Medicine", waitTime: "25 min", doctor: "Dr. Priya Nair", available: true },
    { name: "Surgery", waitTime: "35 min", doctor: "Dr. Rajesh Menon", available: false },
    { name: "Orthopedics", waitTime: "20 min", doctor: "Dr. Sunil Kumar", available: true },
  ]

  const notifications = [
    { id: 1, message: "Your token T001 will be called in 5 minutes", time: "2 min ago", type: "info" },
    { id: 2, message: "Lab results are ready for collection", time: "10 min ago", type: "success" },
    { id: 3, message: "Pharmacy: Insulin stock temporarily unavailable", time: "15 min ago", type: "warning" },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Heart className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-lg font-bold text-gray-900">UDAL</h1>
                <p className="text-xs text-gray-500">Wenlock Hospital</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="ghost" size="sm">
                <Bell className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm">
                <User className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Search Bar */}
      <div className="px-4 py-3 bg-white border-b">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search departments, doctors, services..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Current Token Status */}
      <div className="px-4 py-3">
        <Card className="border-l-4 border-l-blue-600 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-lg">Your Token: {userToken}</h3>
                <p className="text-sm text-gray-600">Cardiology Department</p>
                <p className="text-sm text-blue-600">
                  Position: {queuePosition} | Est. wait: {estimatedTime}
                </p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-lg">
                  {queuePosition}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="px-4 py-3">
        <h2 className="text-lg font-semibold mb-3">Quick Actions</h2>
        <div className="grid grid-cols-2 gap-3">
          {quickActions.map((action, index) => (
            <Button key={index} variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
              {action.icon}
              <span className="text-sm">{action.label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Notifications */}
      <div className="px-4 py-3">
        <h2 className="text-lg font-semibold mb-3">Notifications</h2>
        <div className="space-y-2">
          {notifications.map((notification) => (
            <Card key={notification.id} className="border-l-4 border-l-blue-400">
              <CardContent className="p-3">
                <p className="text-sm">{notification.message}</p>
                <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Departments */}
      <div className="px-4 py-3">
        <h2 className="text-lg font-semibold mb-3">Departments</h2>
        <div className="space-y-3">
          {departments.map((dept, index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-medium">{dept.name}</h3>
                    <p className="text-sm text-gray-600">{dept.doctor}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Clock className="h-3 w-3 text-gray-400" />
                      <span className="text-xs text-gray-500">Wait: {dept.waitTime}</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-end space-y-2">
                    <Badge
                      variant={dept.available ? "default" : "secondary"}
                      className={dept.available ? "bg-green-500" : ""}
                    >
                      {dept.available ? "Available" : "Busy"}
                    </Badge>
                    <Button size="sm" variant="outline">
                      <Navigation className="h-3 w-3 mr-1" />
                      Navigate
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Emergency Contact */}
      <div className="px-4 py-3 pb-6">
        <Card className="border-2 border-red-500 bg-red-50">
          <CardContent className="p-4 text-center">
            <h3 className="font-bold text-red-800 mb-2">Emergency Contact</h3>
            <Button className="w-full bg-red-600 hover:bg-red-700">
              <Phone className="h-4 w-4 mr-2" />
              Call Emergency: 108
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
