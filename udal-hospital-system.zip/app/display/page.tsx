"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Heart, Clock, Users, AlertTriangle, Monitor, Pill } from "lucide-react"
import {
  fetchCSVData,
  CSV_URLS,
  type DrugInventory,
  type TokenQueue,
  type Department,
  type BloodBank,
  type EmergencyAlert,
} from "@/lib/data-utils"

// This would be a full-screen display component for the 73 LG screens
export default function DisplayScreen() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [currentView, setCurrentView] = useState(0)
  const [drugInventory, setDrugInventory] = useState<DrugInventory[]>([])
  const [tokenQueue, setTokenQueue] = useState<TokenQueue[]>([])
  const [departments, setDepartments] = useState<Department[]>([])
  const [bloodBank, setBloodBank] = useState<BloodBank[]>([])
  const [emergencyAlerts, setEmergencyAlerts] = useState<EmergencyAlert[]>([])
  const [loading, setLoading] = useState(true)

  // Rotate between different views every 30 seconds
  const views = ["queue", "ot", "emergency", "inventory"]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    const viewTimer = setInterval(() => {
      setCurrentView((prev) => (prev + 1) % views.length)
    }, 30000)

    return () => {
      clearInterval(timer)
      clearInterval(viewTimer)
    }
  }, [])

  useEffect(() => {
    async function loadData() {
      setLoading(true)
      try {
        const [drugData, tokenData, deptData, bloodData, alertData] = await Promise.all([
          fetchCSVData(CSV_URLS.drugInventory),
          fetchCSVData(CSV_URLS.tokenQueue),
          fetchCSVData(CSV_URLS.departments),
          fetchCSVData(CSV_URLS.bloodBank),
          fetchCSVData(CSV_URLS.emergencyAlerts),
        ])

        setDrugInventory(drugData as DrugInventory[])
        setTokenQueue(tokenData as TokenQueue[])
        setDepartments(deptData as Department[])
        setBloodBank(bloodData as BloodBank[])

        // Filter only active emergency alerts
        const activeAlerts = (alertData as EmergencyAlert[]).filter((alert) => alert.status.toLowerCase() === "active")
        setEmergencyAlerts(activeAlerts)
      } catch (error) {
        console.error("Error loading data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()

    // Simulate real-time updates by refreshing data every 15 seconds
    const dataRefreshInterval = setInterval(() => {
      loadData()
    }, 15000)

    return () => clearInterval(dataRefreshInterval)
  }, [])

  // Mock OT data (not provided in CSV)
  const mockOTData = {
    otStatus: [
      { ot: "OT1", patient: "S. Babu", status: "In Progress", progress: 65 },
      { ot: "OT2", patient: "A. Rao", status: "Pre-Op", progress: 0 },
      { ot: "OT3", patient: "R. Krishnan", status: "Post-Op", progress: 100 },
    ],
  }

  // Get critical drugs for inventory view
  const criticalDrugs = drugInventory
    .filter((drug) => drug.status.toLowerCase() === "critical" || drug.status.toLowerCase() === "low")
    .slice(0, 2)

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Heart className="h-16 w-16 text-blue-400 animate-pulse mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-gray-900">Loading Display...</h1>
          <p className="text-xl text-gray-500">Please wait while we fetch the latest data</p>
        </div>
      </div>
    )
  }

  const renderQueueView = () => {
    // Get the first 3 tokens for display
    const displayTokens = tokenQueue.slice(0, 3)

    return (
      <div className="space-y-8">
        <div className="text-center">
          <h1 className="text-6xl font-bold text-blue-600 mb-4">Current Queue</h1>
          <p className="text-2xl text-gray-600">Please wait for your token to be called</p>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {displayTokens.map((token, index) => {
            // Find the department name
            const department = departments.find((d) => d.dept_id === token.dept_id)
            const status = index === 0 ? "Now Serving" : index === 1 ? "Next" : "Waiting"

            return (
              <Card
                key={token.token_id}
                className={`
                ${
                  index === 0
                    ? "border-4 border-green-500 bg-green-50"
                    : index === 1
                      ? "border-4 border-yellow-500 bg-yellow-50"
                      : "border-2 border-gray-300"
                }
              `}
              >
                <CardContent className="p-8">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-6">
                      <div
                        className={`
                        text-4xl font-bold px-6 py-4 rounded-lg
                        ${
                          index === 0
                            ? "bg-green-500 text-white"
                            : index === 1
                              ? "bg-yellow-500 text-white"
                              : "bg-gray-500 text-white"
                        }
                      `}
                      >
                        {token.token_id}
                      </div>
                      <div>
                        <h2 className="text-3xl font-bold">{token.patient_name}</h2>
                        <p className="text-xl text-gray-600">{department?.department_name || token.dept_id}</p>
                      </div>
                    </div>
                    <Badge
                      variant="outline"
                      className={`
                        text-xl px-4 py-2
                        ${
                          index === 0
                            ? "border-green-500 text-green-700 bg-green-100"
                            : index === 1
                              ? "border-yellow-500 text-yellow-700 bg-yellow-100"
                              : "border-gray-500 text-gray-700 bg-gray-100"
                        }
                      `}
                    >
                      {status}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    )
  }

  const renderOTView = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-blue-600 mb-4">Operation Theater Status</h1>
        <p className="text-2xl text-gray-600">Live updates from surgical departments</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {mockOTData.otStatus.map((ot) => (
          <Card key={ot.ot} className="border-4 border-blue-400">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl">{ot.ot}</CardTitle>
              <Badge
                variant="outline"
                className={`
                  text-lg px-3 py-1
                  ${
                    ot.status === "In Progress"
                      ? "border-green-500 text-green-700 bg-green-100"
                      : ot.status === "Pre-Op"
                        ? "border-yellow-500 text-yellow-700 bg-yellow-100"
                        : "border-blue-500 text-blue-700 bg-blue-100"
                  }
                `}
              >
                {ot.status}
              </Badge>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-xl font-medium text-center">Patient: {ot.patient}</p>
              {ot.status === "In Progress" && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{ot.progress}%</span>
                  </div>
                  <Progress value={ot.progress} className="h-3" />
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )

  const renderEmergencyView = () => (
    <div className="space-y-8">
      {emergencyAlerts.length > 0 ? (
        <Card className="border-4 border-red-500 bg-red-50 animate-pulse">
          <CardContent className="p-8">
            <div className="flex items-center justify-center space-x-4">
              <AlertTriangle className="h-16 w-16 text-red-600" />
              <div className="text-center">
                <h1 className="text-6xl font-bold text-red-600 mb-2">{emergencyAlerts[0].code_type}</h1>
                <p className="text-3xl text-red-700">Location: {emergencyAlerts[0].department}</p>
                <p className="text-xl text-red-600">
                  Alert issued {new Date(emergencyAlerts[0].timestamp).toLocaleTimeString()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-4 border-green-500 bg-green-50">
          <CardContent className="p-8 text-center">
            <h1 className="text-6xl font-bold text-green-600 mb-2">No Active Emergencies</h1>
            <p className="text-2xl text-green-700">All systems normal</p>
          </CardContent>
        </Card>
      )}

      <div className="text-center">
        <h2 className="text-4xl font-bold text-gray-800 mb-4">Emergency Response Protocols</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-lg">
          <Card className="border-2 border-blue-400">
            <CardContent className="p-4 text-center">
              <h3 className="font-bold text-blue-600">Code Blue</h3>
              <p className="text-sm">Cardiac Emergency</p>
            </CardContent>
          </Card>
          <Card className="border-2 border-red-400">
            <CardContent className="p-4 text-center">
              <h3 className="font-bold text-red-600">Code Red</h3>
              <p className="text-sm">Fire Emergency</p>
            </CardContent>
          </Card>
          <Card className="border-2 border-pink-400">
            <CardContent className="p-4 text-center">
              <h3 className="font-bold text-pink-600">Code Pink</h3>
              <p className="text-sm">Child Abduction</p>
            </CardContent>
          </Card>
          <Card className="border-2 border-yellow-400">
            <CardContent className="p-4 text-center">
              <h3 className="font-bold text-yellow-600">Code Yellow</h3>
              <p className="text-sm">Bomb Threat</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )

  const renderInventoryView = () => (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-blue-600 mb-4">Critical Inventory Alert</h1>
        <p className="text-2xl text-gray-600">Immediate attention required</p>
      </div>

      <div className="space-y-6">
        {criticalDrugs.map((drug) => (
          <Card key={drug.drug_id} className="border-4 border-red-400 bg-red-50">
            <CardContent className="p-8">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-6">
                  <Pill className="h-16 w-16 text-red-600" />
                  <div>
                    <h2 className="text-4xl font-bold">{drug.drug_name}</h2>
                    <p className="text-2xl text-gray-600">{drug.stock_qty} units remaining</p>
                  </div>
                </div>
                <Badge variant="destructive" className="text-2xl px-6 py-3">
                  {drug.status}
                </Badge>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Blood bank critical items */}
        {bloodBank
          .filter((blood) => blood.status.toLowerCase() === "critical")
          .map((blood) => (
            <Card key={blood.blood_id} className="border-4 border-red-400 bg-red-50">
              <CardContent className="p-8">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-6">
                    <Heart className="h-16 w-16 text-red-600" />
                    <div>
                      <h2 className="text-4xl font-bold">Blood Type: {blood.blood_type}</h2>
                      <p className="text-2xl text-gray-600">Only {blood.units_available} units remaining</p>
                    </div>
                  </div>
                  <Badge variant="destructive" className="text-2xl px-6 py-3">
                    {blood.status}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
      </div>
    </div>
  )

  const getCurrentView = () => {
    // If there's an active emergency, always show the emergency view
    if (emergencyAlerts.length > 0) {
      return renderEmergencyView()
    }

    // Otherwise, rotate through views
    switch (views[currentView]) {
      case "queue":
        return renderQueueView()
      case "ot":
        return renderOTView()
      case "emergency":
        return renderEmergencyView()
      case "inventory":
        return renderInventoryView()
      default:
        return renderQueueView()
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white p-8">
      {/* Header */}
      <header className="flex justify-between items-center mb-8">
        <div className="flex items-center space-x-4">
          <Heart className="h-12 w-12 text-blue-600" />
          <div>
            <h1 className="text-4xl font-bold text-gray-900">UDAL</h1>
            <p className="text-xl text-gray-600">Wenlock Hospital</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-blue-600">{currentTime.toLocaleTimeString("en-IN")}</p>
          <p className="text-lg text-gray-600">{currentTime.toLocaleDateString("en-IN")}</p>
        </div>
      </header>

      {/* Main Content */}
      <main>{getCurrentView()}</main>

      {/* Footer */}
      <footer className="mt-8 text-center">
        <div className="flex justify-center space-x-8 text-lg text-gray-600">
          <div className="flex items-center space-x-2">
            <Users className="h-5 w-5" />
            <span>{tokenQueue.length} Patients Today</span>
          </div>
          <div className="flex items-center space-x-2">
            <Monitor className="h-5 w-5" />
            <span>3/5 OTs Active</span>
          </div>
          <div className="flex items-center space-x-2">
            <Clock className="h-5 w-5" />
            <span>Avg Wait: 23 min</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
